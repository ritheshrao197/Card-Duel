using System.Collections.Generic;
using CardDuel.Cards;
using CardDuel.Utils;

namespace CardDuel.Core
{
    public class PlayerState
    {
        public string PlayerId { get;  set; }
        public ulong LastClientId { get;  set; }
        public bool IsConnected { get;  set; }
        public int Score { get;  set; }

        private readonly List<CardDefinition> _deck = new();
        private readonly List<CardDefinition> _hand = new();
        private readonly List<CardInstance> _foldedCards = new();

        public IReadOnlyList<CardDefinition> Deck => _deck;
        public IReadOnlyList<CardDefinition> Hand => _hand;
        public IReadOnlyList<CardInstance> FoldedCards => _foldedCards;

        public PlayerState(string playerId, ulong clientId, List<CardDefinition> startingDeck)
        {
            PlayerId = playerId;
            LastClientId = clientId;
            IsConnected = true;
            Score = 0;

            _deck.AddRange(startingDeck);

            Logger.Log(LogCategory.Gameplay, $"PlayerState | Created | {playerId}");
        }

        // ─────────────────────────────
        // Connection
        // ─────────────────────────────

        public void SetConnection(bool connected)
        {
            IsConnected = connected;

            Logger.Log(
                LogCategory.Gameplay,
                $"PlayerState | {PlayerId} | Connected: {connected}"
            );
        }

        // ─────────────────────────────
        // Card actions
        // ─────────────────────────────

        public bool CanDrawCard()
        {
            return _deck.Count > 0;
        }

        public void DrawCard()
        {
            if (_deck.Count == 0)
            {
                Logger.Log(
                    LogCategory.Gameplay,
                    $"PlayerState | {PlayerId} | Draw failed | Deck empty"
                );
                return;
            }

            var card = _deck[0];
            _deck.RemoveAt(0);
            _hand.Add(card);

            Logger.Log(
                LogCategory.Gameplay,
                $"PlayerState | {PlayerId} | Drew card: {card.name}"
            );
        }

        public CardInstance PlayCard(CardDefinition card)
        {
            if (!_hand.Contains(card))
                return null;

            _hand.Remove(card);

            var instance = new CardInstance(card,1);
            return instance;
        }
        public bool HasCardInHand(CardDefinition card)
        {
            return _hand.Contains(card);
        }

        public void FoldCard(CardInstance card)
        {
            _foldedCards.Add(card);

            Logger.Log(
                LogCategory.Gameplay,
                $"PlayerState | {PlayerId} | Folded card: {card.definition.cardName}"
            );
        }

        // ─────────────────────────────
        // Scoring
        // ─────────────────────────────

        public void AddScore(int amount)
        {
            Score += amount;

            Logger.Log(
                LogCategory.Gameplay,
                $"PlayerState | {PlayerId} | Score: {Score}"
            );
        }
    }
}
