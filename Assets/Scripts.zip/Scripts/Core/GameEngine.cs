using System;
using System.Collections.Generic;

namespace CardDuel.Core
{
    public class GameEngine
    {
        public GameState State { get; private set; }
        public int CurrentTurn { get; private set; }

        private readonly Dictionary<string, PlayerState> _players;
        private readonly List<string> _turnOrder;
        private int _turnIndex;

        public event Action<IGameEvent> OnEvent;

        public GameEngine(Dictionary<string, PlayerState> players)
        {
            _players = players;
            _turnOrder = new List<string>(_players.Keys);
            State = GameState.Matchmaking;
        }

        public void StartGame()
        {
            CurrentTurn = 1;
            _turnIndex = 0;
            State = GameState.Playing;

            Emit(new GameStartEvent());
            EmitTurnChanged();
        }

        public bool IsPlayersTurn(string playerId)
            => _turnOrder[_turnIndex] == playerId;

        public void PlayCard(string playerId, CardDefinition card)
        {
            if (!IsPlayersTurn(playerId))
                return;

            var player = _players[playerId];
            var instance = player.PlayCard(card);

            Emit(new CardPlayedEvent(playerId, instance));
        }

        public void EndTurn(string playerId)
        {
            if (!IsPlayersTurn(playerId))
                return;

            _turnIndex = (_turnIndex + 1) % _turnOrder.Count;
            CurrentTurn++;

            EmitTurnChanged();
        }

        private void EmitTurnChanged()
        {
            Emit(new TurnChangedEvent(
                CurrentTurn,
                _turnOrder[_turnIndex]
            ));
        }

        private void Emit(IGameEvent e)
            => OnEvent?.Invoke(e);
    }

    public interface IGameEvent
    {
    }
}
