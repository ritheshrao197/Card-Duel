using System.Collections.Generic;
using UnityEngine;
using CardDuel.Utils;
using CardDuel.Events;
using Logger = CardDuel.Utils.Logger;
using CardDuel.Cards;

namespace CardDuel.Core
{
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance;

        public GameState CurrentState { get; private set; } = GameState.None;

        public int CurrentTurn { get; private set; }

        private readonly Dictionary<string, PlayerState> _players = new();
        public IReadOnlyDictionary<string, PlayerState> Players => _players;
        private readonly List<string> _turnOrder = new();
        private int _turnIndex;
        private GameEngine _engine;

        private void Start()
        {
            _engine = new GameEngine(_players);
            _engine.OnEvent += e => EventBus.Publish(e);
            EnterMatchmaking();

        }


        private void Awake()
        {
            if (Instance != null)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            DontDestroyOnLoad(gameObject);

            Logger.Log(LogCategory.Gameplay, "GameManager | Initialized");
        }

      

        // ─────────────────────────────
        // State transitions
        // ─────────────────────────────

        private void SetState(GameState newState)
        {
            if (CurrentState == newState)
                return;

            Logger.Log(
                LogCategory.Gameplay,
                $"GameManager | State {CurrentState} -> {newState}"
            );

            CurrentState = newState;
        }

        public void EnterMatchmaking()
        {
            SetState(GameState.Matchmaking);
            EventBus.Publish(new MatchmakingStartedEvent());
        }

        public void StartGame()
        {
            if (_players.Count == 0)
            {
                Logger.Log(LogCategory.Gameplay, "StartGame failed | No players");
                return;
            }

            _turnOrder.Clear();
            _turnOrder.AddRange(_players.Keys);

            _turnIndex = 0;
            CurrentTurn = 1;

            SetState(GameState.Playing);

            Logger.Log(
                LogCategory.Gameplay,
                $"GamePlayManager | Game Started | First turn: {_turnOrder[_turnIndex]}"
            );

            EventBus.Publish(new GameStartEvent());
            EventBus.Publish(new TurnChangedEvent(CurrentTurn, _turnOrder[_turnIndex]));
        }
        public string CurrentTurnPlayerId =>
            _turnOrder.Count > 0 ? _turnOrder[_turnIndex] : null;

        public bool IsPlayersTurn(string playerId)
        {
            return CurrentState == GameState.Playing &&
                   playerId == CurrentTurnPlayerId;
        }

        public void PlayCard(string playerId, CardDefinition card)
        {
            if (CurrentState != GameState.Playing)
            {
                Logger.Log(LogCategory.Gameplay, "PlayCard denied | Game not in Playing state");
                return;
            }

            if (!IsPlayersTurn(playerId))
            {
                Logger.Log(
                    LogCategory.Gameplay,
                    $"PlayCard denied | Not {playerId}'s turn"
                );
                return;
            }

            var player = GetPlayer(playerId);
            if (player == null)
            {
                Logger.Log(LogCategory.Gameplay, $"PlayCard failed | Player not found: {playerId}");
                return;
            }

            if (!player.HasCardInHand(card))
            {
                Logger.Log(
                    LogCategory.Gameplay,
                    $"PlayCard denied | Player does not have card: {card.name}"
                );
                return;
            }

            var cardInstance = player.PlayCard(card);

            Logger.Log(
                LogCategory.Gameplay,
                $"Card played | Player {playerId} | Card {card.name}"
            );

            EventBus.Publish(new CardPlayedEvent(playerId, cardInstance));
        }

        public void OpponentDisconnected(float timeout)
        {
            SetState(GameState.PendingGameOver);
            EventBus.Publish(new PendingGameOverEvent(timeout));
        }

        public void ResumeGame()
        {
            SetState(GameState.Playing);
            EventBus.Publish(new MatchResumedEvent());
        }

        public void EndGame()
        {
            SetState(GameState.GameOver);
            EventBus.Publish(new GameEndEvent());
        }

        public void EnterSpectatorMode()
        {
            SetState(GameState.Spectator);
            EventBus.Publish(new SpectatorModeEvent());
        }

        // ─────────────────────────────
        // Turn logic
        // ─────────────────────────────

        public void EndTurn(string requestingPlayerId)
        {
            if (CurrentState != GameState.Playing)
            {
                Logger.Log(LogCategory.Gameplay, "EndTurn ignored | Not in Playing state");
                return;
            }

            if (!IsPlayersTurn(requestingPlayerId))
            {
                Logger.Log(
                    LogCategory.Gameplay,
                    $"EndTurn denied | Not {requestingPlayerId}'s turn"
                );
                return;
            }

            _turnIndex = (_turnIndex + 1) % _turnOrder.Count;
            CurrentTurn++;

            Logger.Log(
                LogCategory.Gameplay,
                $"Turn advanced | Turn {CurrentTurn} | Player {_turnOrder[_turnIndex]}"
            );

            EventBus.Publish(new TurnChangedEvent(CurrentTurn, _turnOrder[_turnIndex]));
        }



        // ─────────────────────────────
        // Player management
        // ─────────────────────────────

        public void AddPlayer(string playerId, PlayerState state)
        {
            if (_players.ContainsKey(playerId))
            {
                Logger.Log(LogCategory.Gameplay, $"Player already exists: {playerId}");
                return;
            }

            _players[playerId] = state;
            Logger.Log(LogCategory.Gameplay, $"Player added: {playerId}");
        }

        public PlayerState GetPlayer(string playerId)
        {
            _players.TryGetValue(playerId, out var player);
            return player;
        }
    }
}
