using CardDuel.UI.Core;

namespace CardDuel.UI.Game
{
    public class GameplayPanel : UIPanel
    {
        // Intentionally empty
        // This panel is only shown/hidden by UIManager
    }
}