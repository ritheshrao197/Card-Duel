using CardDuel.Networking.Netcode;
using UnityEngine;

namespace CardDuel.UI.Game
{
    public class EndTurnButtonUI : MonoBehaviour
    {
        public void OnEndTurnClicked()
        {
            NetworkClient.SendEndTurn();
        }
    }
}
