// using CardDuel.Events;
// using TMPro;
// using UnityEngine;

// namespace CardDuel.UI.Game
// {
//     public class TurnTimerUI : MonoBehaviour
//     {
//         [SerializeField] private TextMeshProUGUI timerText;

//         private void OnEnable()
//         {
//             EventBus.Subscribe<TurnTimerTickEvent>(OnTick);
//         }

//         private void OnDisable()
//         {
//             EventBus.Unsubscribe<TurnTimerTickEvent>(OnTick);
//         }

//         private void OnTick(TurnTimerTickEvent e)
//         {
//             timerText.text = $"{Mathf.CeilToInt(e.remainingTime)}s";
//         }
//     }
// }