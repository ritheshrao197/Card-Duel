using CardDuel.Core;
using CardDuel.Events;
using TMPro;
using UnityEngine;

namespace CardDuel.UI.Game
{
    public class GameplayHUD : MonoBehaviour
    {
        [Header("Top Bar")]
        [SerializeField] private TextMeshProUGUI turnText;
        [SerializeField] private TextMeshProUGUI timerText;

        [Header("Scores")]
        [SerializeField] private TextMeshProUGUI myScoreText;
        [SerializeField] private TextMeshProUGUI opponentScoreText;

        private void OnEnable()
        {
            EventBus.Subscribe<TurnStartEvent>(OnTurnStart);
            EventBus.Subscribe<ScoreUpdatedEvent>(OnScoreUpdated);
            EventBus.Subscribe<FullStateSyncEvent>(OnFullStateSync);
        }

        private void OnDisable()
        {
            EventBus.Unsubscribe<TurnStartEvent>(OnTurnStart);
            EventBus.Unsubscribe<ScoreUpdatedEvent>(OnScoreUpdated);
            EventBus.Unsubscribe<FullStateSyncEvent>(OnFullStateSync);
        }

        private void OnTurnStart(TurnStartEvent e)
        {
            turnText.text = $"Turn {e.turnNumber}";
        }

        private void OnScoreUpdated(ScoreUpdatedEvent e)
        {
            myScoreText.text = $"You: {e.playerScore}";
            opponentScoreText.text = $"Opponent: {e.opponentScore}";
        }

        private void OnFullStateSync(FullStateSyncEvent e)
        {
            turnText.text = $"Turn {e.snapshot.currentTurn}";
            UpdateScores(e.snapshot.scores);
            timerText.text = $"{Mathf.CeilToInt(e.snapshot.remainingTurnTime)}s";

        }

        private void UpdateScores(
            System.Collections.Generic.Dictionary<string, int> scores)
        {
            foreach (var kv in scores)
            {
                if (kv.Key == LocalPlayerContext.PlayerId)
                    myScoreText.text = $"You: {kv.Value}";
                else
                    opponentScoreText.text = $"Opponent: {kv.Value}";
            }
        }

        // private void OnFullStateSync(FullStateSyncEvent e)
        // {
        //     turnText.text = $"Turn {e.snapshot.currentTurn}";
        //     UpdateScores(e.snapshot.scores);
        // }

    }
}