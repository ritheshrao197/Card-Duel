namespace CardDuel.Core
{
    public enum GamePhase
    {
        PreviewDraw,   // showing 3 cards to active player
        Playing,       // selection phase
        Revealing,
        GameOver
    }
}
