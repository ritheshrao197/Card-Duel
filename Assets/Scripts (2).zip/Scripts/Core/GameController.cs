using CardDuel.Core.Commands;

namespace CardDuel.Core
{
    public class GameController
    {
        private readonly GameEngine _engine;

        public GameController(GameEngine engine)
        {
            _engine = engine;
        }

        public void Submit(IGameCommand command)
        {
            command.Execute(_engine);
        }
    }
}
