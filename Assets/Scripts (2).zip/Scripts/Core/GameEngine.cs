using System;
using System.Collections.Generic;
using CardDuel.Core.Events;
using CardDuel.Cards;
using CardDuel.Events;
using CardDuel.Gameplay;

namespace CardDuel.Core
{
    public class GameEngine
    {
        public event Action<IGameEvent> OnEvent;

        public GamePhase Phase { get; private set; } = GamePhase.PreviewDraw;
        public int CurrentTurn { get; private set; } = 1;

        private readonly Dictionary<string, PlayerState> _players;
        private readonly List<string> _turnOrder;
        private int _turnIndex;
        private readonly HashSet<string> _endedTurn = new();

        private readonly RevealManager _reveal;

        public GameEngine(Dictionary<string, PlayerState> players)
        {
            _players = players;
            _turnOrder = new List<string>(players.Keys);
            _reveal = new RevealManager(this);
        }

        internal void Emit(IGameEvent e) => OnEvent?.Invoke(e);

        public void StartTurn()
        {
            Phase = GamePhase.PreviewDraw;
            var p = _players[_turnOrder[_turnIndex]];
            Emit(new DrawPreviewEvent(p.PlayerId, p.GetRandomPreviewCards(3)));
        }

        internal void DrawPreviewCard(string playerId, CardDefinition card)
        {
            if (Phase != GamePhase.PreviewDraw) return;
            if (_turnOrder[_turnIndex] != playerId) return;

            var p = _players[playerId];
            if (!p.Deck.Contains(card)) return;

            p.Deck.Remove(card);
            p.Hand.Add(card);

            Phase = GamePhase.Playing;
            Emit(new CardDrawnEvent(playerId, card));
        }

        internal void FoldCard(string playerId, CardDefinition card)
        {
            if (Phase != GamePhase.Playing) return;
            if (_turnOrder[_turnIndex] != playerId) return;

            var p = _players[playerId];
            if (!p.Hand.Contains(card)) return;

            int usedCost = 0;
            foreach (var c in p.FoldedCards)
                usedCost += c.Definition.cost;

            if (usedCost + card.cost > CurrentTurn) return;

            p.Hand.Remove(card);
            p.FoldedCards.Add(new CardInstance(card));

            Emit(new CardFoldedEvent(playerId, p.FoldedCards.Count));
        }

        internal void EndTurn(string playerId)
        {
            if (_turnOrder[_turnIndex] != playerId) return;
            if (_endedTurn.Contains(playerId)) return;

            _endedTurn.Add(playerId);
            Emit(new PlayerEndedTurnEvent(playerId));

            _turnIndex = (_turnIndex + 1) % _turnOrder.Count;

            if (_endedTurn.Count == _players.Count)
            {
                Phase = GamePhase.Revealing;
                _endedTurn.Clear();
                Emit(new RevealStartedEvent(CurrentTurn));
                _reveal.StartReveal(
                    _players[_turnOrder[0]],
                    _players[_turnOrder[1]]
                );
            }
            else
            {
                StartTurn();
            }
        }

        internal void NotifyRevealFinished()
        {
            CurrentTurn++;
            if (CurrentTurn > 6)
            {
                Phase = GamePhase.GameOver;
                Emit(new GameEndEvent(GetWinner()));
                return;
            }

            Emit(new TurnStartEvent(CurrentTurn));
            StartTurn();
        }

        private string GetWinner()
        {
            string best = null;
            int score = int.MinValue;

            foreach (var p in _players.Values)
            {
                if (p.Score > score)
                {
                    score = p.Score;
                    best = p.PlayerId;
                }
            }
            return best;
        }

        public PlayerState GetOpponent(PlayerState p)
        {
            foreach (var o in _players.Values)
                if (o != p) return o;
            return null;
        }
    }
}
// using System;
// using System.Collections.Generic;
// using CardDuel.Core.Events;
// using CardDuel.Cards;
// using CardDuel.Events;

// namespace CardDuel.Core
// {

//     public class GameEngine
//     {
//         public event Action<IGameEvent> OnEvent;

//         public GamePhase Phase { get; private set; } = GamePhase.PreviewDraw;
//         public int CurrentTurn { get; private set; } = 1;
//         public int TOTAL_TURNS =6;

//         private readonly Dictionary<string, PlayerState> _players;
//         private readonly List<string> _turnOrder;
//         private int _turnIndex;

//         private readonly HashSet<string> _endedTurn = new();

//         public GameEngine(Dictionary<string, PlayerState> players)
//         {
//             _players = players;
//             _turnOrder = new List<string>(players.Keys);
//         }

//         internal void Emit(IGameEvent evt)
//         {
//             OnEvent?.Invoke(evt);
//         }

//         // ================= DRAW PREVIEW =================

//         public void StartTurn()
//         {
//             Phase = GamePhase.PreviewDraw;

//             var playerId = _turnOrder[_turnIndex];
//             var player = _players[playerId];

//             Emit(new DrawPreviewEvent(
//                 playerId,
//                 player.GetRandomPreviewCards(3)
//             ));
//         }

//         public void DrawPreviewCard(string playerId, CardDefinition card)
//         {
//             if (Phase != GamePhase.PreviewDraw) return;
//             if (_turnOrder[_turnIndex] != playerId) return;

//             var player = _players[playerId];
//             if (!player.Deck.Contains(card)) return;

//             player.Deck.Remove(card);
//             player.Hand.Add(card);

//             Phase = GamePhase.Playing;

//             Emit(new CardDrawnEvent(playerId, card));
//         }

//         // ================= TURN END =================

//         public void EndTurn(string playerId)
//         {
//             if (_turnOrder[_turnIndex] != playerId) return;

//             _endedTurn.Add(playerId);
//             Emit(new PlayerEndedTurnEvent(playerId));

//             AdvanceTurn();
//         }

//         private void AdvanceTurn()
//         {
//             _turnIndex = (_turnIndex + 1) % _turnOrder.Count;

//             if (_endedTurn.Count == _players.Count)
//             {
//                 StartReveal();
//                 return;
//             }

//             StartTurn();
//         }

//         private void StartReveal()
//         {
//             Phase = GamePhase.Revealing;
//             _endedTurn.Clear();

//             Emit(new RevealStartedEvent(CurrentTurn));
//             // RevealManager runs here (already implemented)
//         }

//         public void OnRevealFinished()
//         {
//             CurrentTurn++;

//             if (CurrentTurn > TOTAL_TURNS)
//             {
//                 Phase = GamePhase.GameOver;
//                 Emit(new GameEndEvent(GetWinner()));
//                 return;
//             }

//             Phase = GamePhase.Playing;
//             Emit(new TurnStartEvent(CurrentTurn));
//         }


//         private string GetWinner()
//         {
//             string winnerId = null;
//             int bestScore = int.MinValue;

//             foreach (var kv in _players)
//             {
//                 var player = kv.Value;

//                 if (player.Score > bestScore)
//                 {
//                     bestScore = player.Score;
//                     winnerId = player.PlayerId;
//                 }
//                 else if (player.Score == bestScore)
//                 {
//                     // Deterministic tie-breaker:
//                     // earlier in turn order wins
//                     if (_turnOrder.IndexOf(player.PlayerId) <
//                         _turnOrder.IndexOf(winnerId))
//                     {
//                         winnerId = player.PlayerId;
//                     }
//                 }
//             }

//             return winnerId;
//         }

//         internal void FoldCard(string playerId, CardDefinition card)
//         {
//             if (Phase != GamePhase.Playing)
//                 return;

//             // Turn ownership validation
//             if (_turnOrder[_turnIndex] != playerId)
//                 return;

//             var player = _players[playerId];

//             // Card must be in hand
//             if (!player.Hand.Contains(card))
//                 return;

//             // Cost validation
//             int usedCost = 0;
//             foreach (var c in player.FoldedCards)
//                 usedCost += c.Definition.cost;

//             if (usedCost + card.cost > CurrentTurn)
//                 return;

//             // Move card: Hand → Folded
//             player.Hand.Remove(card);
//             player.FoldedCards.Add(new CardInstance(card));

//             Emit(new CardFoldedEvent(
//                 playerId,
//                 player.FoldedCards.Count
//             ));
//         }

//     }
// }