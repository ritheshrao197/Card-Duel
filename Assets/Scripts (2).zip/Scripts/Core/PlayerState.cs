using System;
using System.Collections.Generic;
using CardDuel.Cards;

namespace CardDuel.Core
{
    public class PlayerState
    {
        public string PlayerId { get; }
        public int Score { get; private set; }

        public readonly List<CardDefinition> Deck = new();
        public readonly List<CardDefinition> Hand = new();
        public readonly List<CardInstance> FoldedCards = new();

        public PlayerState(string playerId, List<CardDefinition> deck)
        {
            PlayerId = playerId;
            Deck.AddRange(deck);
        }

        public void DrawCard()
        {
            if (Deck.Count == 0) return;
            Hand.Add(Deck[0]);
            Deck.RemoveAt(0);
        }

        public CardInstance PlayCard(CardDefinition card)
        {
            if (!Hand.Remove(card)) return null;
            return new CardInstance(card);
        }

        public void Fold(CardInstance card)
        {
            FoldedCards.Add(card);
        }

        public void AddScore(int value)
        {
            Score += value;
        }

        public bool HasCardInHand(CardDefinition card)
        {
            return Hand.Contains(card);
        }

        internal CardDefinition[] GetRandomPreviewCards(int v)
        {
            throw new NotImplementedException();
        }
    }
}
