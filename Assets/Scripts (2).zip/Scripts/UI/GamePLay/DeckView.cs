using UnityEngine;
using UnityEngine.Events;
using CardDuel.Cards;

public class DeckView : MonoBehaviour
{
    public UnityEvent<CardDefinition> OnCardClicked;

    public void ShowPreview(CardDefinition[] cards)
    {
        // Instantiate card buttons
    }
}
