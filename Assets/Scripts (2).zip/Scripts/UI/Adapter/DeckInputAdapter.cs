using UnityEngine;
using CardDuel.Core;
using CardDuel.Core.Commands;
using CardDuel.Cards;

public class DeckInputAdapter : MonoBehaviour
{
    [SerializeField] private DeckView view;
    private GameController _controller;
    private string _playerId;

    public void Init(GameController controller, string playerId)
    {
        _controller = controller;
        _playerId = playerId;

        view.OnCardClicked.AddListener(OnCardClicked);
    }

    private void OnCardClicked(CardDefinition card)
    {
        _controller.Submit(new DrawPreviewCardCommand
        {
            PlayerId = _playerId,
            Card = card
        });
    }
}
