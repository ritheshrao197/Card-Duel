using UnityEngine;
using UnityEngine.UI;
using CardDuel.UI.Core;
using CardDuel.Utils;
using CardDuel.Networking.Netcode;
using Logger = CardDuel.Utils.Logger;
using CardDuel.Events;
using CardDuel.UI.Events;

namespace CardDuel.UI.MainMenu
{
    public class MainMenuPanel : UIPanel
    {
        [SerializeField] private Button hostButton;
        [SerializeField] private Button joinButton;

        private void Awake()
        {
            hostButton.onClick.AddListener(OnHostClicked);
            joinButton.onClick.AddListener(OnJoinClicked);
        }
        public void OnHostClicked()
        {
            Logger.Log(LogCategory.UI, "MainMenu | Host clicked");
            EventBus.Publish(new HostClickedEvent());
        }

        public void OnJoinClicked()
        {
            Logger.Log(LogCategory.UI, "MainMenu | Join clicked");
            EventBus.Publish(new JoinClickedEvent());
        }
        // private void StartHost()
        // {
        //     Logger.Log(LogCategory.UI, "MainMenu | Start Host");
        //     FindObjectOfType<NetworkBootstrap>().StartHost();
        // }

        // private void StartClient()
        // {
        //     Logger.Log(LogCategory.UI, "MainMenu | Start Client");
        //     FindObjectOfType<NetworkBootstrap>().StartClient();
        // }
    }
}