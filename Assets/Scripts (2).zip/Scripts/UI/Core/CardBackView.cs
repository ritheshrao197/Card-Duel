
using UnityEngine;

namespace CardDuel.UI.Gameplay
{
    public class CardBackView : MonoBehaviour
    {
        public static void Create(Transform parent)
        {
            var prefab = Resources.Load<GameObject>("UI/CardBack");
            Instantiate(prefab, parent);
        }
    }
}
