using CardDuel.Events;
using CardDuel.UI.Core;
using CardDuel.UI.Events;
using CardDuel.Utils;
using UnityEngine;
using Logger = CardDuel.Utils.Logger;

namespace CardDuel.UI
{
    public class UIFlowController : MonoBehaviour
    {
        private void OnEnable()
        {
            EventBus.Subscribe<HostClickedEvent>(OnHostClicked);
            EventBus.Subscribe<JoinClickedEvent>(OnJoinClicked);
            EventBus.Subscribe<GameStartEvent>(OnGameStart);
            EventBus.Subscribe<GameEndEvent>(OnGameEnd);
        }

        private void OnDisable()
        {
            EventBus.Unsubscribe<HostClickedEvent>(OnHostClicked);
            EventBus.Unsubscribe<JoinClickedEvent>(OnJoinClicked);
            EventBus.Unsubscribe<GameStartEvent>(OnGameStart);
            EventBus.Unsubscribe<GameEndEvent>(OnGameEnd);
        }

        private void OnHostClicked(HostClickedEvent e)
        {
            Logger.Log(LogCategory.UI, "UIFlow | Host clicked → Matchmaking");
            UIManager.Instance.SwitchTo(UIState.Matchmaking);
        }

        private void OnJoinClicked(JoinClickedEvent e)
        {
            Logger.Log(LogCategory.UI, "UIFlow | Join clicked → Matchmaking");
            UIManager.Instance.SwitchTo(UIState.Matchmaking);
        }

        private void OnGameStart(GameStartEvent e)
        {
            UIManager.Instance.SwitchTo(UIState.Gameplay);
        }

        private void OnGameEnd(GameEndEvent e)
        {
            UIManager.Instance.SwitchTo(UIState.GameOver);
        }
    }
}
