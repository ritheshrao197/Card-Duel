using UnityEngine;
using UnityEngine.UI;
using TMPro;
using CardDuel.UI.Core;
using CardDuel.Events;
using CardDuel.Networking;
using CardDuel.Utils;
using CardDuel.Networking.Netcode;

namespace CardDuel.UI.Gameplay
{
    public class GameplayPanel : UIPanel
    {
        [Header("Texts")]
        [SerializeField] private TextMeshProUGUI turnText;
        [SerializeField] private TextMeshProUGUI costText;

        [Header("Buttons")]
        [SerializeField] private Button endTurnButton;

        [Header("Areas")]
        [SerializeField] private Transform previewArea;
        [SerializeField] private Transform handArea;
        [SerializeField] private Transform opponentFoldArea;

        private void Awake()
        {
            endTurnButton.onClick.AddListener(OnEndTurnClicked);
        }

        public override void SubscribeToEvents()
        {
            EventBus.Subscribe<TurnStartEvent>(OnTurnStart);
            EventBus.Subscribe<DrawPreviewEvent>(OnDrawPreview);
            EventBus.Subscribe<CardDrawnEvent>(OnCardDrawn);
            EventBus.Subscribe<CardFoldedEvent>(OnCardFolded);
        }

        public override void UnsubscribeFromEvents()
        {
            EventBus.Unsubscribe<TurnStartEvent>(OnTurnStart);
            EventBus.Unsubscribe<DrawPreviewEvent>(OnDrawPreview);
            EventBus.Unsubscribe<CardDrawnEvent>(OnCardDrawn);
            EventBus.Unsubscribe<CardFoldedEvent>(OnCardFolded);
        }

        // ---------------- EVENTS ----------------

        private void OnTurnStart(TurnStartEvent e)
        {
            turnText.text = $"Turn {e.currentTurn}";
            costText.text = $"Cost: {e.availableCost}";
            endTurnButton.interactable = true;
        }

        private void OnDrawPreview(DrawPreviewEvent e)
        {
            previewArea.DestroyChildren();

            foreach (var card in e.previewCards)
            {
                var view = CardView.Create(card, previewArea);
                view.OnClick += () =>
                {
                    NetworkClient.Send(new NetworkMessage
                    {
                        action = "drawPreviewCard",
                        payload = JsonUtility.ToJson(new DrawPreviewPayload
                        {
                            playerId = e.playerId,
                            cardId = card.id
                        })
                    });
                };
            }
        }

        private void OnCardDrawn(CardDrawnEvent e)
        {
            previewArea.DestroyChildren();

            var view = CardView.Create(e.card, handArea);
            view.SetInteractable(true);
        }

        private void OnCardFolded(CardFoldedEvent e)
        {
            opponentFoldArea.DestroyChildren();

            for (int i = 0; i < e.foldedCount; i++)
            {
                CardBackView.Create(opponentFoldArea);
            }
        }

        private void OnEndTurnClicked()
        {
            endTurnButton.interactable = false;

            NetworkClient.Send(new NetworkMessage
            {
                action = "endTurn",
                payload = JsonUtility.ToJson(new EndTurnPayload
                {
                    playerId = NetworkClient.LocalPlayerId
                })
            });
        }
    }
}