using TMPro;
using UnityEngine.UI;
using UnityEngine;
using CardDuel.Events;
using CardDuel.Networking;
using CardDuel.UI.Core;
using CardDuel.Utils;
using Logger = CardDuel.Utils.Logger;
using CardDuel.Networking.Netcode;

namespace CardDuel.UI.Matchmaking
{
    public class MatchmakingPanel : UIPanel
    {
        [SerializeField] private TextMeshProUGUI statusText;
        [SerializeField] private TextMeshProUGUI playerCountText;
        [SerializeField] private Button readyButton;

        private bool _isReady;

        private void Awake()
        {
            readyButton.interactable = false;
            statusText.text = "Waiting for players…";
        }

        public override void SubscribeToEvents()
        {
            Logger.Log(LogCategory.UI, "MatchmakingPanel | Subscribed");
            EventBus.Subscribe<PlayerConnectionStateEvent>(OnPlayerConnectionState);
            EventBus.Subscribe<GameStartEvent>(OnGameStart);
        }

        public override void UnsubscribeFromEvents()
        {
            EventBus.Unsubscribe<PlayerConnectionStateEvent>(OnPlayerConnectionState);
            EventBus.Unsubscribe<GameStartEvent>(OnGameStart);
        }

        public void SetReady()
        {
            if (_isReady)
                return;

            _isReady = true;
            readyButton.interactable = false;
            statusText.text = "Ready. Waiting for opponent…";

            Logger.Log(LogCategory.UI, "Matchmaking | Player Ready");

            NetworkClient.Send(new NetworkMessage
            {
                action = "playerReady",
                payload = "{}"
            });
        }

        private void OnPlayerConnectionState(PlayerConnectionStateEvent e)
        {
            Logger.Log(
          LogCategory.UI,
          $"MatchmakingPanel | PlayerConnectionStateEvent | count={e.connectedPlayers}"
      );
       playerCountText.text = $"Players: {e.connectedPlayers}/2";

            if (e.connectedPlayers < 2)
            {
                statusText.text = "Waiting for opponent…";
                readyButton.interactable = false;
                return;
            }

            statusText.text = _isReady
                ? "Waiting for opponent to ready up…"
                : "Opponent found. Press Ready.";

            readyButton.interactable = !_isReady;
        }

        private void OnGameStart(GameStartEvent e)
        {
            Logger.Log(LogCategory.UI, "Matchmaking | Game Start");
            UIManager.Instance.SwitchTo(UIState.Gameplay);
        }
    }
}
