using TMPro;
using CardDuel.UI.Core;
using CardDuel.Events;
using UnityEngine;

namespace CardDuel.UI.GameOver
{
    public class GameOverPanel : UIPanel
    {
        [SerializeField] private TextMeshProUGUI resultText;

        public override void SubscribeToEvents()
        {
            EventBus.Subscribe<GameEndEvent>(OnGameEnd);
        }

        public override void UnsubscribeFromEvents()
        {
            EventBus.Unsubscribe<GameEndEvent>(OnGameEnd);
        }

        private void OnGameEnd(GameEndEvent e)
        {
            resultText.text = $"Winner: {e.winnerId}";
        }
    }
}
