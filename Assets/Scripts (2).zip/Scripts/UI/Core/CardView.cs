
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;
namespace CardDuel.UI.Gameplay
{
    public class CardView : MonoBehaviour
    {
        public Action OnClick;

        [SerializeField] private TextMeshProUGUI nameText;
        [SerializeField] private TextMeshProUGUI costText;
        [SerializeField] private Button button;

        public static CardView Create(CardDuel.Cards.CardDefinition def, Transform parent)
        {
            var prefab = Resources.Load<CardView>("UI/CardView");
            var view = Instantiate(prefab, parent);

            view.nameText.text = def.cardName;
            view.costText.text = def.cost.ToString();
            view.button.onClick.AddListener(() => view.OnClick?.Invoke());

            return view;
        }

        public void SetInteractable(bool value)
        {
            button.interactable = value;
        }
    }
}