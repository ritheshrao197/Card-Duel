using CardDuel.Events;
using UnityEngine;

public class HandPresenter : MonoBehaviour
{
    // private void OnEnable()
    // {
    //     EventBus.Subscribe<CardDrawnEvent>(OnDraw);
    // }

    // private void OnDraw(CardDrawnEvent e)
    // {
    //     if (!IsLocalPlayer(e.PlayerId)) return;
    //     SpawnCard(e.Card);
    // }
}
