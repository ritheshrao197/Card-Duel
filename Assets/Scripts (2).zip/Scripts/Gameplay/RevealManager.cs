using CardDuel.Cards;
using CardDuel.Events;

namespace CardDuel.Core
{
    public class RevealManager
    {
        private readonly GameEngine _engine;
        private PlayerState _first, _second;
        private int _index;

        public RevealManager(GameEngine engine)
        {
            _engine = engine;
        }

        public void StartReveal(PlayerState a, PlayerState b)
        {
            _first = a.Score >= b.Score ? a : b;
            _second = _first == a ? b : a;

            _index = 0;
            RevealNext();
        }

        private void RevealNext()
        {
            bool any = false;

            if (_index < _first.FoldedCards.Count)
            {
                Resolve(_first, _engine.GetOpponent(_first), _first.FoldedCards[_index]);
                any = true;
            }

            if (_index < _second.FoldedCards.Count)
            {
                Resolve(_second, _engine.GetOpponent(_second), _second.FoldedCards[_index]);
                any = true;
            }

            _index++;

            if (any) RevealNext();
            else _engine.NotifyRevealFinished();
        }

        private void Resolve(PlayerState owner, PlayerState opp, CardInstance card)
        {
            owner.AddScore(card.EffectivePower);
            _engine.Emit(new ScoreUpdatedEvent(owner.PlayerId, owner.Score));
            _engine.Emit(new CardRevealedEvent(owner.PlayerId, card.Definition.id, _index));
        }
    }
}
// using CardDuel.Core;
// using CardDuel.Cards;
// using CardDuel.Cards.Abilities;
// using CardDuel.Events;
// using System.Collections.Generic;

// namespace CardDuel.Gameplay
// {
//     /// <summary>
//     /// RevealManager
//     /// -----------------
//     /// Responsible ONLY for:
//     /// - Determining initiative at reveal start
//     /// - Revealing folded cards in alternating order
//     /// - Resolving power + abilities
//     ///
//     /// Does NOT:
//     /// - Decide turns
//     /// - End the game
//     /// - Talk to UI or networking
//     ///
//     /// Controlled entirely by GameEngine.
//     /// </summary>
//     public sealed class RevealManager
//     {
//         private readonly GameEngine _engine;

//         private PlayerState _initiativePlayer;
//         private PlayerState _otherPlayer;

//         private int _revealIndex;
//         private bool _initiativeTurn;

//         private bool _isRevealing;

//         public bool IsRevealing => _isRevealing;

//         public RevealManager(GameEngine engine)
//         {
//             _engine = engine;
//         }

//         /// <summary>
//         /// Called ONCE by GameEngine when both players ended their turn.
//         /// Locks initiative and prepares reveal state.
//         /// </summary>
//         public void BeginReveal(PlayerState a, PlayerState b)
//         {
//             // Decide initiative ONCE
//             if (a.Score > b.Score)
//             {
//                 _initiativePlayer = a;
//                 _otherPlayer = b;
//             }
//             else if (b.Score > a.Score)
//             {
//                 _initiativePlayer = b;
//                 _otherPlayer = a;
//             }
//             else
//             {
//                 // Tie → deterministic random
//                 if (UnityEngine.Random.value > 0.5f)
//                 {
//                     _initiativePlayer = a;
//                     _otherPlayer = b;
//                 }
//                 else
//                 {
//                     _initiativePlayer = b;
//                     _otherPlayer = a;
//                 }
//             }

//             _revealIndex = 0;
//             _initiativeTurn = true;
//             _isRevealing = true;
//         }

//         /// <summary>
//         /// Advances reveal by ONE card.
//         /// Call repeatedly until IsRevealing == false.
//         /// </summary>
//         public void TickReveal()
//         {
//             if (!_isRevealing)
//                 return;

//             var current = _initiativeTurn
//                 ? _initiativePlayer
//                 : _otherPlayer;

//             var opponent = _initiativeTurn
//                 ? _otherPlayer
//                 : _initiativePlayer;

//             // Check if this player has a card at this index
//             if (_revealIndex < current.FoldedCards.Count)
//             {
//                 ResolveSingleCard(current, opponent, current.FoldedCards[_revealIndex]);
//             }

//             // Switch player for alternating reveal
//             _initiativeTurn = !_initiativeTurn;

//             // If both players have revealed at this index → advance index
//             if (_initiativeTurn)
//                 _revealIndex++;

//             // End condition: no cards left for both players
//             if (_revealIndex >= _initiativePlayer.FoldedCards.Count &&
//                 _revealIndex >= _otherPlayer.FoldedCards.Count)
//             {
//                 FinishReveal();
//             }
//         }

//         private void ResolveSingleCard(
//             PlayerState owner,
//             PlayerState opponent,
//             CardInstance card)
//         {
//             // 1. Apply base power
//             owner.AddScore(card.EffectivePower);

//             // 2. Resolve ability (if any)
//             if (card.Definition.ability != null)
//             {
//                 AbilitySystem.Resolve(
//                     new AbilityContext(owner, opponent, card)
//                 );
//             }

//             // 3. Emit score update AFTER every reveal
//             _engine.Emit(
//                 new ScoreUpdatedEvent(owner.PlayerId, owner.Score)
//             );

//             // 4. Emit reveal event
//             _engine.Emit(
//                 new CardRevealedEvent(
//                     owner.PlayerId,
//                     card.Definition.id,
//                     _revealIndex
//                 )
//             );
//         }

//         private void FinishReveal()
//         {
//             _isRevealing = false;

//             // Clear folded cards AFTER reveal
//             _initiativePlayer.FoldedCards.Clear();
//             _otherPlayer.FoldedCards.Clear();

//             _engine.OnRevealFinished();
//         }
//     }
// }
