using CardDuel.Events;
using CardDuel.UI.Events;
using Unity.Netcode;
using UnityEngine;

public class NetworkBootstrap : MonoBehaviour
{
    private void OnEnable()
    {
        EventBus.Subscribe<HostClickedEvent>(_ => StartHost());
        EventBus.Subscribe<JoinClickedEvent>(_ => StartClient());
    }

    private void OnDisable()
    {
        EventBus.Unsubscribe<HostClickedEvent>(_ => StartHost());
        EventBus.Unsubscribe<JoinClickedEvent>(_ => StartClient());
    }

    private void StartHost()
    {
        NetworkManager.Singleton.StartHost();
    }

    private void StartClient()
    {
        NetworkManager.Singleton.StartClient();
    }
}
