
using UnityEngine;
using CardDuel.Core.Events;
using CardDuel.Networking.Payloads;
using CardDuel.Events;

namespace CardDuel.Networking
{
    /// <summary>
    /// Converts GameEngine events ↔ network JSON messages.
    /// This is the ONLY place that knows event ↔ action mapping.
    /// </summary>
    public static class NetworkEventSerializer
    {
        // =============================
        // SERVER → CLIENT
        // =============================
        public static NetworkMessage Serialize(object gameEvent)
        {
            switch (gameEvent)
            {
                case GameStartEvent e:
                    return new NetworkMessage
                    {
                        action = "gameStart",
                        payload = JsonUtility.ToJson(e)
                    };

                case TurnStartEvent e:
                    return new NetworkMessage
                    {
                        action = "turnStart",
                        payload = JsonUtility.ToJson(e)
                    };

                case DrawPreviewEvent e:
                    return new NetworkMessage
                    {
                        action = "drawPreview",
                        payload = JsonUtility.ToJson(e)
                    };

                case CardDrawnEvent e:
                    return new NetworkMessage
                    {
                        action = "cardDrawn",
                        payload = JsonUtility.ToJson(e)
                    };

                case PlayerEndedTurnEvent e:
                    return new NetworkMessage
                    {
                        action = "playerEndedTurn",
                        payload = JsonUtility.ToJson(e)
                    };

                case RevealStartedEvent e:
                    return new NetworkMessage
                    {
                        action = "revealStarted",
                        payload = JsonUtility.ToJson(e)
                    };

                case CardRevealedEvent e:
                    return new NetworkMessage
                    {
                        action = "cardRevealed",
                        payload = JsonUtility.ToJson(e)
                    };

                case ScoreUpdatedEvent e:
                    return new NetworkMessage
                    {
                        action = "scoreUpdated",
                        payload = JsonUtility.ToJson(e)
                    };

                case GameEndEvent e:
                    return new NetworkMessage
                    {
                        action = "gameEnd",
                        payload = JsonUtility.ToJson(e)
                    };
            }

            Debug.LogWarning(
                $"[NetworkEventSerializer] Unknown event type: {gameEvent.GetType()}"
            );
            return null;
        }

        // =============================
        // CLIENT → LOCAL EVENTS
        // =============================
        public static object Deserialize(NetworkMessage msg)
        {
            switch (msg.action)
            {
                case "gameStart":
                    return JsonUtility.FromJson<GameStartEvent>(msg.payload);

                case "turnStart":
                    return JsonUtility.FromJson<TurnStartEvent>(msg.payload);

                case "drawPreview":
                    return JsonUtility.FromJson<DrawPreviewEvent>(msg.payload);

                case "cardDrawn":
                    return JsonUtility.FromJson<CardDrawnEvent>(msg.payload);

                case "playerEndedTurn":
                    return JsonUtility.FromJson<PlayerEndedTurnEvent>(msg.payload);

                case "revealStarted":
                    return JsonUtility.FromJson<RevealStartedEvent>(msg.payload);

                case "cardRevealed":
                    return JsonUtility.FromJson<CardRevealedEvent>(msg.payload);

                case "scoreUpdated":
                    return JsonUtility.FromJson<ScoreUpdatedEvent>(msg.payload);

                case "gameEnd":
                    return JsonUtility.FromJson<GameEndEvent>(msg.payload);
            }

            Debug.LogWarning(
                $"[NetworkEventSerializer] Unknown action: {msg.action}"
            );
            return null;
        }
    }
}

