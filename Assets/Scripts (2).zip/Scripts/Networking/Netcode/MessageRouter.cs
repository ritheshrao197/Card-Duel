using UnityEngine;
using CardDuel.Events;
using CardDuel.Utils;
using CardDuel.Networking.Netcode;
using CardDuel.Core;
using CardDuel.Networking.Payloads;
using Logger = CardDuel.Utils.Logger;
using CardDuel.Networking.Sync;

namespace CardDuel.Networking
{
    public static class MessageRouter
    {
        public static void RouteFromServer(string json)
        {
            var msg = JsonUtility.FromJson<NetworkMessage>(json);

            var evt = NetworkEventSerializer.Deserialize(msg);
            if (evt != null)
                EventBus.Publish(evt);
        }
    }
}

// ============================
// CLIENT → SERVER
// ============================
// public static void Route(ulong clientId, NetworkMessage msg)
// {
//     Logger.Log(
//         LogCategory.Network,
//         $"[C→S] Action '{msg.action}' from client {clientId}"
//     );

//     switch (msg.action)
//     {
//         case "playerReady":
//             NetworkGameController.Instance.SetPlayerReady(clientId);
//             break;

//         case "endTurn":
//             {
//                 var payload = JsonUtility.FromJson<EndTurnPayload>(msg.payload);

//                 // Forward intent to GameManager → GameEngine
//                 GameManager.Instance.EndTurn(payload.playerId);
//                 break;
//             }

//         case "playCard":
//             {
//                 var payload = JsonUtility.FromJson<PlayCardPayload>(msg.payload);

//                 GameManager.Instance.PlayCard(
//                     payload.playerId,
//                     payload.cardDefinition
//                 );
//                 break;
//             }

//         case "leaveMatch":
//             NetworkGameController.Instance.HandleManualLeave(clientId);
//             break;

//         default:
//             Logger.Log(
//                 LogCategory.Network,
//                 $"Ignoring unknown server action: {msg.action}"
//             );
//             break;

//     }
// }

// ============================
// SERVER → CLIENT
// ============================
