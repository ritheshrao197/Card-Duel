using Unity.Netcode;
using UnityEngine;
using CardDuel.Core;
using CardDuel.Core.Commands;
using CardDuel.Cards;
using CardDuel.Networking.Payloads;
using CardDuel.Utils;
using Logger = CardDuel.Utils.Logger;

namespace CardDuel.Networking.Netcode
{
    /// <summary>
    /// NetworkGameController is a COMMAND ROUTER.
    ///
    /// Responsibilities:
    /// - Receive JSON from clients
    /// - Validate server authority
    /// - Convert JSON → Commands
    /// - Submit commands to GameController
    /// - Broadcast Engine events as JSON
    ///
    /// DOES NOT:
    /// - Execute gameplay logic
    /// - Modify GameState
    /// - Call GameEngine methods directly
    /// </summary>
    public class NetworkGameController : NetworkBehaviour
    {
        public static NetworkGameController Instance;

        private GameController _gameController;
        public int ConnectedPlayerCount { get; private set; }


        private void Awake()
        {
            if (Instance != null)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            DontDestroyOnLoad(gameObject);
        }

        public override void OnNetworkSpawn()
        {
            if (!IsServer) return;

            _gameController = GameBootstrap.Instance.GameController;

            Logger.Log(LogCategory.Network, "NetworkGameController | Command Router active");
        }

        // =============================
        // CLIENT → SERVER (JSON → Command)
        // =============================
        public void OnMessageFromClient(ulong clientId, string json)
        {
            var msg = JsonUtility.FromJson<NetworkMessage>(json);

            Logger.Log(
                LogCategory.Network,
                $"[C→S] {msg.action} from client {clientId}"
            );

            if (!IsServer)
                return;

            switch (msg.action)
            {
                case "drawPreviewCard":
                    HandleDrawPreview(msg.payload);
                    break;

                case "endTurn":
                    HandleEndTurn(msg.payload);
                    break;

                default:
                    Logger.Warn(
                        LogCategory.Network,
                        $"Unhandled client action: {msg.action}"
                    );
                    break;
            }
        }

        // =============================
        // HANDLERS (payload → command)
        // =============================

        private void HandleDrawPreview(string payload)
        {
            var data = JsonUtility.FromJson<DrawPreviewPayload>(payload);

            var card = CardDatabase.GetById(data.cardId);
            if (card == null)
                return;

            _gameController.Submit(new DrawPreviewCardCommand
            {
                PlayerId = data.playerId,
                Card = card
            });
        }

        private void HandleEndTurn(string payload)
        {
            var data = JsonUtility.FromJson<EndTurnPayload>(payload);

            _gameController.Submit(new EndTurnCommand
            {
                PlayerId = data.playerId
            });
        }

        // =============================
        // SERVER → CLIENT (Events → JSON)
        // =============================

        public void BroadcastEvent(object evt)
        {
            var message = NetworkEventSerializer.Serialize(evt);
            if (message == null) return;

            SendEventClientRpc(JsonUtility.ToJson(message));
        }


        [ClientRpc]
        private void SendEventClientRpc(string json)
        {
            MessageRouter.RouteFromServer(json);
        }
    }
}