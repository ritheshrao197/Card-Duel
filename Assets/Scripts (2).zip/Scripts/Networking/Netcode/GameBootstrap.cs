using UnityEngine;
using CardDuel.Utils;
using Logger = CardDuel.Utils.Logger;
using System.Collections.Generic;

namespace CardDuel.Core
{
    /// <summary>
    /// GameBootstrap is the composition root.
    /// It wires Engine → Controller → Event routing.
    /// Created ONCE on server & client.
    /// </summary>
    public class GameBootstrap : MonoBehaviour
    {
        public static GameBootstrap Instance { get; private set; }

        public GameEngine Engine { get; private set; }
        public GameController GameController { get; private set; }

        private void Awake()
        {
            if (Instance != null)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            DontDestroyOnLoad(gameObject);

            Bootstrap();
        }

        private void Bootstrap()
        {
            // Create shared player dictionary (filled by session layer)
            var players = new Dictionary<string, PlayerState>();

            Engine = new GameEngine(players);
            GameController = new GameController(Engine);

            Logger.Log(LogCategory.Gameplay, "GameBootstrap | Initialized");
        }
    }
}
