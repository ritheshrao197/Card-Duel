using UnityEngine;
using CardDuel.Utils;
using CardDuel.Networking.Netcode;
using Logger = CardDuel.Utils.Logger;
using NetworkPlayer = CardDuel.Networking.Netcode.NetworkPlayer;

namespace CardDuel.Networking
{
    /// <summary>
    /// Client-side networking façade.
    /// UI and input talk ONLY to this class.
    /// </summary>
    public static class NetworkClient
    {
        private static NetworkPlayer _player;

        /// <summary>
        /// Gameplay playerId (P1 / P2).
        /// Set once by server.
        /// </summary>
        public static string LocalPlayerId { get; private set; }

        public static void Initialize(NetworkPlayer player)
        {
            _player = player;

            Logger.Log(
                LogCategory.Network,
                $"NetworkClient initialized. OwnerClientId={player.OwnerClientId}"
            );
        }

        public static void SetLocalPlayerId(string playerId)
        {
            LocalPlayerId = playerId;

            Logger.Log(
                LogCategory.Network,
                $"LocalPlayerId set to {playerId}"
            );
        }

        public static void Send(NetworkMessage message)
        {
            if (_player == null)
            {
                Logger.Warn(LogCategory.Network, "NetworkClient.Send failed | Player not initialized");
                return;
            }

            var json = JsonUtility.ToJson(message);
            _player.SendMessageServerRpc(json);
        }
    }
}
// using System;
// using CardDuel.Events;
// using CardDuel.Utils;
// using UnityEngine;

// namespace CardDuel.Networking.Netcode
// {
//     public static class NetworkClient
//     {
//         private static NetworkPlayer _player;

//         public static void Initialize(NetworkPlayer player)
//         {
//             _player = player;
//             EventBus.Subscribe<EndTurnPressedEvent>(_ => SendEndTurn());
//         }

//         public static void SendEndTurn()
//         {
//             Send(new NetworkMessage
//             {
//                 action = "endTurn",
//                 payload = "{}"
//             });
//         }

//         public static void SendTest()
//         {
//             Send(new NetworkMessage
//             {
//                 action = "test",
//                 payload = "{ \"msg\": \"hello\" }"
//             });
//         }
//         public static void SendPlayerReady()
//         {
//             Send(new NetworkMessage
//             {
//                 action = "playerReady",
//                 payload = "{}"
//             });
//         }

//         public static void Send(NetworkMessage msg)
//         {
//             string json = JsonUtility.ToJson(msg);
//             Utils.Logger.Log(LogCategory.Network, $"Client sending {msg.action}");
//             _player.SendMessageServerRpc(json);
//         }

//     }
// }
