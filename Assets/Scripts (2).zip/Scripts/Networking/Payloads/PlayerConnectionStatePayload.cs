using System;

namespace CardDuel.Networking.Payloads
{
    [Serializable]
    public class PlayerConnectionStatePayload
    {
        public int connectedPlayers;

        public PlayerConnectionStatePayload(int connected)
        {
            this.connectedPlayers = connected;
        }
    }
}