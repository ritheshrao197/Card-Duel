using System;

[Serializable]
public class EndTurnPayload
{
    public string playerId;
}
