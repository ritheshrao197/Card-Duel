[System.Serializable]
public class SyncBoardPayload
{
    public int opponentCardCount;
}
