using System;
using CardDuel.Cards;

namespace CardDuel.Networking.Payloads
{
    [Serializable]
    public class PlayerDisconnectedPayload
    {
        public string playerId;
    }
}

namespace CardDuel.Networking.Payloads
{
    [System.Serializable]
    public class EndTurnPayload
    {
        public string playerId;
    }
}

namespace CardDuel.Networking.Payloads
{
    [System.Serializable]
    public class PlayCardPayload
    {
        public string playerId;
        public CardDefinition cardDefinition;
    }
}
