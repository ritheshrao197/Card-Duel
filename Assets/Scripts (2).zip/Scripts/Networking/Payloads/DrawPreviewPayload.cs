using System;

[Serializable]
public class DrawPreviewPayload
{
    public string playerId;
    public int cardId;
}
