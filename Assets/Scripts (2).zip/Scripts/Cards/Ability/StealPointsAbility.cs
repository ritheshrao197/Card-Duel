
namespace CardDuel.Cards.Abilities
{
    public class StealPointsAbility : ICardAbility
{
    public void Resolve(AbilityContext context)
    {
        int stolen = context.Opponent.Score;
            context.Opponent.AddScore(-stolen);
            context.Self.AddScore(stolen);
    }
}

}