using CardDuel.Core;
using CardDuel.Cards;

namespace CardDuel.Cards.Abilities
{
    // Context passed to every ability during reveal resolution
    public class AbilityContext
    {
        public PlayerState Self { get; }
        public PlayerState Opponent { get; }
        public CardInstance Card { get; }

        public AbilityContext(
            PlayerState self,
            PlayerState opponent,
            CardInstance card)
        {
            Self = self;
            Opponent = opponent;
            Card = card;
        }
    }
}
