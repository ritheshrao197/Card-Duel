
namespace CardDuel.Cards.Abilities
{
    public class DestroyOpponentCardInPlayAbility : ICardAbility
    {
        public void Resolve(AbilityContext context)
        {
            context.Opponent.AddScore(
                context.Card.Definition.ability.value
            );
        }
    }
}
