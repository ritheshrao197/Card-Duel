namespace CardDuel.Cards.Abilities
{
    public class GainPointsAbility : ICardAbility
    {
        public void Resolve(AbilityContext context)
        {
            context.Self.AddScore(
                context.Card.Definition.ability.value
            );
        }
    }
}
