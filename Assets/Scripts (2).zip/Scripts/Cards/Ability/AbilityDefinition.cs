namespace CardDuel.Cards.Abilities
{
    [System.Serializable]
    public class AbilityDefinition
    {
        public string type;
        public int value;
    }
}
