namespace CardDuel.Cards.Abilities
{
    // All card abilities must implement this interface.
    // Resolve is called during the Reveal phase.
    public interface ICardAbility
    {
        void Resolve(AbilityContext context);
    }
}
