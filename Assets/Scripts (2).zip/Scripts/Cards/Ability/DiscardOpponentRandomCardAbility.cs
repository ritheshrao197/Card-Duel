using UnityEngine;

namespace CardDuel.Cards.Abilities
{
    public class DiscardOpponentRandomCardAbility : ICardAbility
{
 
        public void Resolve(AbilityContext context)
        {
            // for (int i = 0; i < context.Opponent.ca; i++)
            // {
            //     if (context.opponent.hand.Count == 0)
            //         return;

            //     int index = Random.Range(0, context.opponent.hand.Count);
            //     context.opponent.hand.RemoveAt(index);
            // }
        }
    }

}