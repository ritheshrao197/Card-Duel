namespace CardDuel.Cards.Abilities
{
    public class DrawExtraCardAbility : ICardAbility
    {
        public void Resolve(AbilityContext context)
        {

        }
    }

}