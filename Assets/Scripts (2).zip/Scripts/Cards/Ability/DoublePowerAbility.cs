
namespace CardDuel.Cards.Abilities
{
    public class DoublePowerAbility : ICardAbility
    {
        public void Resolve(AbilityContext context)
        {
            context.Card.EffectivePower *= 2;
        }


    }

}