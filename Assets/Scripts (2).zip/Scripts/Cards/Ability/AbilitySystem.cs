using System;
using System.Collections.Generic;

namespace CardDuel.Cards.Abilities
{
    public static class AbilitySystem
    {
        // Factory map: ability type → constructor
        private static readonly Dictionary<string, Func<ICardAbility>> _abilityFactory
            = new Dictionary<string, Func<ICardAbility>>
        {
            { "GainPoints", () => new GainPointsAbility() },
            { "StealPoints", () => new StealPointsAbility() },
            { "DoublePower", () => new DoublePowerAbility() },
            { "DrawExtraCard", () => new DrawExtraCardAbility() },
            { "DiscardOpponentRandomCard", () => new DiscardOpponentRandomCardAbility() },
            { "DestroyOpponentCardInPlay", () => new DestroyOpponentCardInPlayAbility() }
        };

        /// <summary>
        /// Creates a runtime ability instance from a data-driven AbilityDefinition.
        /// Returns null if the card has no ability or the type is unknown.
        /// </summary>
        public static ICardAbility CreateAbility(string definitionType)
        {
            if (string.IsNullOrEmpty(definitionType))
                return null;

            if (_abilityFactory.TryGetValue(definitionType, out var creator))
                return creator();

            UnityEngine.Debug.LogWarning(
                $"AbilitySystem | Unknown ability type: {definitionType}"
            );

            return null;
        }

        /// <summary>
        /// Resolves a card ability safely using context.
        /// </summary>
        public static void Resolve(AbilityContext context)
        {
            var ability = CreateAbility(context.Card.Definition.ability.type);
            ability?.Resolve(context);
        }
    }
}
