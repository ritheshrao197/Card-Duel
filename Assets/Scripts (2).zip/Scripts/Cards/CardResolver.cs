using CardDuel.Cards.Abilities;
using CardDuel.Core;

namespace CardDuel.Cards 
{
    public static class CardResolver
{
    public static void ResolveCard(
        CardInstance card,
        PlayerState owner,
        PlayerState opponent)
    {
        // Apply base power
        owner.AddScore( card.EffectivePower);

        // Resolve ability
        if (card.Definition.ability != null &&
            !string.IsNullOrEmpty(card.Definition.ability.type))
        {
            var ability = AbilitySystem.CreateAbility(card.Definition.ability.type);
            var context = new AbilityContext(owner, opponent, card);
            ability.Resolve(context);
        }
    }
}

}