
using System.Collections.Generic;
using CardDuel.Cards.Abilities;
using UnityEngine;

namespace CardDuel.Cards
{
    public static class CardLoader
    {
        public static List<CardDefinition> LoadFromJson(TextAsset json)
        {
            var wrapper = JsonUtility.FromJson<CardListWrapper>(json.text);
            var cards = new List<CardDefinition>();

            foreach (var data in wrapper.cards)
            {
                var def = ScriptableObject.CreateInstance<CardDefinition>();
                def.id = data.id;
                def.cardName = data.cardName;
                def.cost = data.cost;
                def.power = data.power;
                def.ability = data.ability;

                cards.Add(def);
            }

            return cards;
        }

        [System.Serializable]
        private class CardListWrapper
        {
            public CardJson[] cards;
        }

        [System.Serializable]
        private class CardJson
        {
            public int id;
            public string cardName;
            public int cost;
            public int power;
            public AbilityDefinition ability;
        }
    }
}
