namespace CardDuel.Cards
{
    public class CardInstance
    {
        public CardDefinition Definition { get; }
        public int EffectivePower { get; set; }

        public CardInstance(CardDefinition definition)
        {
            Definition = definition;
            EffectivePower = definition.power;
        }
    }
}