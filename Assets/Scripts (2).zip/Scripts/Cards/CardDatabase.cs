using System.Collections.Generic;
using UnityEngine;

namespace CardDuel.Cards
{
    /// <summary>
    /// Read-only registry of all card definitions.
    /// Loaded once at startup.
    /// </summary>
    public static class CardDatabase
    {
        private static Dictionary<int, CardDefinition> _cardsById;
        private static bool _loaded;

        public static void Load()
        {
            if (_loaded) return;

            _cardsById = new Dictionary<int, CardDefinition>();

            // Load from Resources (or Addressables later)
            var cards = Resources.LoadAll<CardDefinition>("Cards");

            foreach (var card in cards)
            {
                if (_cardsById.ContainsKey(card.id))
                {
                    Debug.LogError($"Duplicate Card ID: {card.id}");
                    continue;
                }

                _cardsById[card.id] = card;
            }

            _loaded = true;
        }

        public static CardDefinition GetById(int id)
        {
            Load();

            _cardsById.TryGetValue(id, out var card);
            return card;
        }

        public static IReadOnlyCollection<CardDefinition> GetAll()
        {
            Load();
            return _cardsById.Values;
        }
    }
}
