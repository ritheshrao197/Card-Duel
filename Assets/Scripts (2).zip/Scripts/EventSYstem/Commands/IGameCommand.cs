namespace CardDuel.Core.Commands
{
    public interface IGameCommand
    {
        void Execute(GameEngine engine);
    }
}