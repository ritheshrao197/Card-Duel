
namespace CardDuel.Core.Commands
{
    public class EndTurnCommand : IGameCommand
    {
        public string PlayerId;

        public void Execute(GameEngine engine)
        {
            engine.EndTurn(PlayerId);
        }
    }
}
