using CardDuel.Cards;

namespace CardDuel.Core.Commands
{
    public struct FoldCardCommand : IGameCommand
    {
        public string PlayerId;
        public CardDefinition Card;

        public void Execute(GameEngine engine)
        {
            engine.FoldCard(PlayerId, Card);
        }
    }
}
