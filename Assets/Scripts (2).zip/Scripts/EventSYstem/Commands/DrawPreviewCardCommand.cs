
using CardDuel.Cards;

namespace CardDuel.Core.Commands
{
    public struct DrawPreviewCardCommand : IGameCommand
    {
        public string PlayerId;
        public CardDefinition Card;

        public void Execute(GameEngine engine)
        {
            engine.DrawPreviewCard(PlayerId, Card);
        }
    }
}