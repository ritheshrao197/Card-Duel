namespace CardDuel.UI.Events
{
    public struct DrawPreviewCardPressed
    {
        public int cardId;
    }
    public struct HostClickedEvent { }
    public struct JoinClickedEvent { }
    public struct EndTurnPressed { }

    public struct FoldCardPressed
    {
        public int cardId;
    }
}
