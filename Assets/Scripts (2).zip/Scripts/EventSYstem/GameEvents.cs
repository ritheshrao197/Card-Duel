using CardDuel.Cards;
using CardDuel.Core.Events;
using CardDuel.Networking.Sync;

namespace CardDuel.Events
{
    // =====================================================
    // GAME LIFECYCLE
    // =====================================================

    public struct GameStartEvent : IGameEvent
    {
        public int totalTurns;
    }
    

    public struct TurnStartEvent : IGameEvent
    {
        public int currentTurn;
        public int availableCost;

        public TurnStartEvent(int currentTurn)
        {
            this.currentTurn = currentTurn;
            this.availableCost = currentTurn;
        }
    }

    public struct GameEndEvent : IGameEvent
    {
        public string winnerId;

        public GameEndEvent(string winnerId)
        {
            this.winnerId = winnerId;
        }
    }

    // =====================================================
    // TURN / FLOW
    // =====================================================

    public struct PlayerEndedTurnEvent : IGameEvent
    {
        public string playerId;

        public PlayerEndedTurnEvent(string playerId)
        {
            this.playerId = playerId;
        }
    }

    public struct RevealStartedEvent : IGameEvent
    {
        public int turn;

        public RevealStartedEvent(int turn)
        {
            this.turn = turn;
        }
    }

    public struct TurnChangedEvent : IGameEvent
    {
        public int turn;
        public string currentPlayerId;

        public TurnChangedEvent(int turn, string currentPlayerId)
        {
            this.turn = turn;
            this.currentPlayerId = currentPlayerId;
        }
    }

    // =====================================================
    // DRAW / HAND
    // =====================================================

    public struct DrawPreviewEvent : IGameEvent
    {
        public string playerId;
        public CardDefinition[] previewCards;

        public DrawPreviewEvent(string playerId, CardDefinition[] previewCards)
        {
            this.playerId = playerId;
            this.previewCards = previewCards;
        }
    }

    public struct CardDrawnEvent : IGameEvent
    {
        public string playerId;
        public CardDefinition card;

        public CardDrawnEvent(string playerId, CardDefinition card)
        {
            this.playerId = playerId;
            this.card = card;
        }
    }

    // =====================================================
    // FOLD / REVEAL
    // =====================================================

    public struct CardFoldedEvent : IGameEvent
    {
        public string playerId;
        public int foldedCount;

        public CardFoldedEvent(string playerId, int foldedCount)
        {
            this.playerId = playerId;
            this.foldedCount = foldedCount;
        }
    }

    public struct CardRevealedEvent : IGameEvent
    {
        public string playerId;
        public int cardId;
        public int revealIndex;

        public CardRevealedEvent(string playerId, int cardId, int revealIndex)
        {
            this.playerId = playerId;
            this.cardId = cardId;
            this.revealIndex = revealIndex;
        }
    }

    public struct ScoreUpdatedEvent : IGameEvent
    {
        public string playerId;
        public int newScore;

        public ScoreUpdatedEvent(string playerId, int newScore)
        {
            this.playerId = playerId;
            this.newScore = newScore;
        }
    }
    internal struct CardPlayedEvent : IGameEvent
    {
        private string playerId;
        private CardInstance cardInstance;

        public CardPlayedEvent(string playerId, CardInstance cardInstance)
        {
            this.playerId = playerId;
            this.cardInstance = cardInstance;
        }
    }

    // =====================================================
    // NETWORK / SESSION
    // =====================================================

    public struct PlayerConnectedEvent : IGameEvent
    {
        public int playerCount;
    }

    public struct PlayerDisconnectedEvent : IGameEvent
    {
        public string playerId;
    }

    public struct PlayerConnectionStateEvent : IGameEvent
    {
        public int connectedPlayers;
    }

    public struct ReconnectCountdownEvent : IGameEvent
    {
        public float remainingTime;

        public ReconnectCountdownEvent(float remainingTime)
        {
            this.remainingTime = remainingTime;
        }
    }

    public struct PendingGameOverEvent : IGameEvent
    {
        public float remainingTime;

        public PendingGameOverEvent(float remainingTime)
        {
            this.remainingTime = remainingTime;
        }
    }

    public struct MatchResumedEvent : IGameEvent { }
    public struct SpectatorModeEvent : IGameEvent { }

    // =====================================================
    // SNAPSHOT
    // =====================================================

    public struct FullStateSyncEvent : IGameEvent
    {
        public GameStateSnapshot snapshot;
    }

    // =====================================================
    // UI INTENT EVENTS (UI → INPUT LAYER ONLY)
    // =====================================================

    public struct EndTurnPressedEvent : IGameEvent { }
    public struct ShowMainMenu : IGameEvent { }
    public struct MatchmakingStartedEvent : IGameEvent { }
}
