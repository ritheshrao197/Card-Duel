namespace CardDuel.Core.Events
{
    /// <summary>
    /// Marker interface for all gameplay events.
    /// GameEngine only emits IGameEvent.
    /// </summary>
    public interface IGameEvent { }
}
