using System.Collections.Generic;
using CardDuel.Domain.Commands;
using CardDuel.Domain.Events;
using CardDuel.Domain.GameState;

namespace Assets.Scripts.Application.UseCases
{
    /// <summary>
    /// Application service that orchestrates game flow
    /// Validates flow, not rules - rules live in domain
    /// </summary>
    public class GameApplicationService
    {
        private readonly GameState _gameState;

        public GameApplicationService(GameState gameState)
        {
            _gameState = gameState;
        }

        /// <summary>
        /// Handle any command and route to appropriate domain logic
        /// This is the traffic controller - it knows when, not how
        /// </summary>
        public IEnumerable<IGameEvent> HandleCommand(ICommand command)
        {
            var events = new List<IGameEvent>();

            switch (command)
            {
                case StartMatchCommand startCmd:
                    events.AddRange(HandleStartMatch(startCmd));
                    break;

                case PlayCardCommand playCmd:
                    events.AddRange(HandlePlayCard(playCmd));
                    break;

                case EndTurnCommand endCmd:
                    events.AddRange(HandleEndTurn(endCmd));
                    break;

                case ConcedeCommand concedeCmd:
                    events.AddRange(HandleConcede(concedeCmd));
                    break;

                case DrawCardCommand drawCmd:
                    events.AddRange(HandleDrawCard(drawCmd));
                    break;
            }

            return events;
        }

        private IEnumerable<IGameEvent> HandleStartMatch(StartMatchCommand command)
        {
            // Validate we can start a match
            if (_gameState.CurrentPhase != GamePhase.WaitingForPlayers)
                return new IGameEvent[] { new CommandRejectedEvent("Match already started") };

            _gameState.AddPlayer(command.PlayerId);
            return _gameState.StartGame();
        }

        private IEnumerable<IGameEvent> HandlePlayCard(PlayCardCommand command)
        {
            // Validate game phase
            if (_gameState.CurrentPhase != GamePhase.TurnInProgress)
                return new IGameEvent[] { new CommandRejectedEvent("Cannot play card outside of turn") };

            return _gameState.PlayCard(command.PlayerId, command.CardId);
        }

        private IEnumerable<IGameEvent> HandleEndTurn(EndTurnCommand command)
        {
            // Validate game phase
            if (_gameState.CurrentPhase != GamePhase.TurnInProgress)
                return new IGameEvent[] { new CommandRejectedEvent("Cannot end turn outside of turn phase") };

            return _gameState.EndPlayerTurn(command.PlayerId);
        }

        private IEnumerable<IGameEvent> HandleConcede(ConcedeCommand command)
        {
            // In a real implementation, this would end the game with the other player as winner
            return new IGameEvent[] { new MatchConcededEvent(command.PlayerId) };
        }

        private IEnumerable<IGameEvent> HandleDrawCard(DrawCardCommand command)
        {
            // Validate game phase and rules
            if (_gameState.CurrentPhase != GamePhase.TurnInProgress)
                return new IGameEvent[] { new CommandRejectedEvent("Cannot draw card outside of turn") };

            // In a real implementation, you'd check deck/hand limits
            return new IGameEvent[] { new CardDrawnEvent(command.PlayerId) };
        }
    }

    /// <summary>
    /// Command rejected event - for flow validation failures
    /// </summary>
    public class CommandRejectedEvent : IGameEvent
    {
        public string Reason { get; }

        public CommandRejectedEvent(string reason)
        {
            Reason = reason;
        }
    }

    /// <summary>
    /// Match conceded event
    /// </summary>
    public class MatchConcededEvent : IGameEvent
    {
        public ulong PlayerId { get; }

        public MatchConcededEvent(ulong playerId)
        {
            PlayerId = playerId;
        }
    }

    /// <summary>
    /// Card drawn event
    /// </summary>
    public class CardDrawnEvent : IGameEvent
    {
        public ulong PlayerId { get; }

        public CardDrawnEvent(ulong playerId)
        {
            PlayerId = playerId;
        }
    }
}