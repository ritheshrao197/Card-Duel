using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;
using CardDuel.Core;

namespace CardDuel.Presentation.UI.Components
{
    /// <summary>
    /// Simplified card display component for cricket cards
    /// Shows basic card information and handles selection
    /// </summary>
    public class CardDisplay : MonoBehaviour
    {
        [Header("UI References")]
        public Image CardArt;
        public TextMeshProUGUI CardNameText;
        public TextMeshProUGUI CostText;
        public TextMeshProUGUI PowerText;
        public TextMeshProUGUI RoleText;
        public TextMeshProUGUI TagsText;
        public TextMeshProUGUI AbilityText;
        public Button CardButton;
        
        [Header("Card Data")]
        public int CardId;
        public string CardName;
        public int Cost;
        public int Power;
        public string Role = "Batsman";
        public List<string> Tags = new List<string>();
        public string AbilityType;
        public int AbilityValue;

        private bool isSelected = false;
        private Color originalColor;
        private ulong playerId = 1;

        void Start()
        {
            StoreOriginalColor();
            InitializeCardDisplay();
        }

        private void StoreOriginalColor()
        {
            var image = GetComponent<Image>();
            if (image != null)
            {
                originalColor = image.color;
            }
        }

        private void InitializeCardDisplay()
        {
            // Set up UI elements
            if (CardNameText != null)
                CardNameText.text = CardName;
                
            if (CostText != null)
                CostText.text = Cost.ToString();
                
            if (PowerText != null)
                PowerText.text = Power.ToString();
                
            if (RoleText != null)
                RoleText.text = Role.ToUpper();
                
            if (TagsText != null)
                TagsText.text = Tags.Count > 0 ? string.Join(", ", Tags) : "No Tags";
                
            if (AbilityText != null)
            {
                if (!string.IsNullOrEmpty(AbilityType))
                    AbilityText.text = $"{AbilityType}: {AbilityValue}";
                else
                    AbilityText.text = "Basic Play";
            }

            if (CardButton != null)
            {
                CardButton.onClick.AddListener(OnCardClicked);
            }
        }

        private void OnCardClicked()
        {
            // Toggle selection visually
            isSelected = !isSelected;
            UpdateVisualSelection();

            // Emit card selection event
            if (isSelected)
            {
                EventBus.Publish(new CardSelectedEvent(CardId, playerId));
            }
            else
            {
                EventBus.Publish(new CardDeselectedEvent(CardId, playerId));
            }
        }

        private void UpdateVisualSelection()
        {
            var image = GetComponent<Image>();
            if (image != null)
            {
                if (isSelected)
                {
                    // Highlight selected card
                    image.color = Color.Lerp(originalColor, Color.yellow, 0.7f);
                    transform.localScale = Vector3.one * 1.1f; // Slightly enlarge
                }
                else
                {
                    // Return to normal
                    image.color = originalColor;
                    transform.localScale = Vector3.one;
                }
            }
        }

        // Public methods for external control
        public void SetSelected(bool selected)
        {
            isSelected = selected;
            UpdateVisualSelection();
        }

        public bool IsSelected()
        {
            return isSelected;
        }

        public void SetPlayerId(ulong playerId)
        {
            this.playerId = playerId;
        }

        public void UpdateCardData(int cardId, string name, int cost, int power, string role = "Batsman", List<string> tags = null, string abilityType = null, int abilityValue = 0)
        {
            CardId = cardId;
            CardName = name;
            Cost = cost;
            Power = power;
            Role = role;
            Tags = tags ?? new List<string>();
            AbilityType = abilityType;
            AbilityValue = abilityValue;
            
            InitializeCardDisplay();
        }

        public void AnimatePlay()
        {
            // Simple animation when card is played
            Debug.Log($"Animating play for card {CardName}");
        }

        public void AnimateHighlight(bool highlight)
        {
            var image = GetComponent<Image>();
            if (image != null)
            {
                if (highlight)
                {
                    // Simple highlight effect
                    image.color = Color.cyan;
                }
                else
                {
                    image.color = originalColor;
                }
            }
        }
    }

    // Simple events for card selection
    public class CardSelectedEvent : IGameEvent
    {
        public int CardId { get; }
        public ulong PlayerId { get; }

        public CardSelectedEvent(int cardId, ulong playerId)
        {
            CardId = cardId;
            PlayerId = playerId;
        }
    }

    public class CardDeselectedEvent : IGameEvent
    {
        public int CardId { get; }
        public ulong PlayerId { get; }

        public CardDeselectedEvent(int cardId, ulong playerId)
        {
            CardId = cardId;
            PlayerId = playerId;
        }
    }
}