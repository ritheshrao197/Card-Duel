using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;
using CardDuel.Core;
using CardDuel.Domain.Events;
using CardDuel.Domain.Commands;
using CardDuel.Infrastructure.Networking;
using CardDuel.Domain.Models.Cricket;
using CardDuel.Presentation.UI.Components;
using CardDuel.Application.UseCases;

namespace CardDuel.Presentation.UI
{
    /// <summary>
    /// Enhanced UI manager for cricket card game
    /// Handles card display, hand management, and game state visualization
    /// </summary>
    public class UIManager : MonoBehaviour
    {
        [Header("UI Panel References")]
        public GameObject HandPanel;
        public GameObject BoardPanel;
        public GameObject InfoPanel;
        public GameObject ControlPanel;

        [Header("UI Element References")]
        public TextMeshProUGUI TurnIndicator;
        public TextMeshProUGUI ScoreText;
        public TextMeshProUGUI TimerText;
        public TextMeshProUGUI StatusText;
        public Button EndTurnButton;
        public Button StartGameButton;

        [Header("Prefabs")]
        public GameObject CardPrefab;

        [Header("Game State")]
        public int LocalPlayerId = 1;
        public int OpponentPlayerId = 2;

        private List<CardDisplay> _handCards = new List<CardDisplay>();
        private List<GameObject> _boardCards = new List<GameObject>();
        private int _localScore = 0;
        private int _opponentScore = 0;
        private int _currentTurn = 1;
        private float _turnTimer = 30f;
        private bool _isGameActive = false;

        void Start()
        {
            SubscribeToEvents();
            InitializeUI();
            SetupDemoHand(); // For testing
        }

        private void SubscribeToEvents()
        {
            // Listen to all relevant domain events
            EventBus.Subscribe<GameStartedEvent>(OnGameStarted);
            EventBus.Subscribe<TurnStartedEvent>(OnTurnStarted);
            EventBus.Subscribe<PlayerEndedTurnEvent>(OnPlayerEndedTurn);
            EventBus.Subscribe<CardPlayedEvent>(OnCardPlayed);
            EventBus.Subscribe<ScoreUpdatedEvent>(OnScoreUpdated);
            EventBus.Subscribe<TurnEndedEvent>(OnTurnEnded);
            EventBus.Subscribe<GameEndedEvent>(OnGameEnded);
            EventBus.Subscribe<CommandRejectedEvent>(OnCommandRejected);
        }

        private void InitializeUI()
        {
            // Setup button listeners
            if (EndTurnButton != null)
            {
                EndTurnButton.onClick.AddListener(OnEndTurnClicked);
                EndTurnButton.interactable = false;
            }

            if (StartGameButton != null)
            {
                StartGameButton.onClick.AddListener(OnStartGameClicked);
            }

            UpdateStatus("Ready to start game");
        }

        // Event Handlers
        private void OnGameStarted(GameStartedEvent evt)
        {
            _isGameActive = true;
            _currentTurn = 1;
            UpdateTurnIndicator(1, evt.TotalTurns);
            UpdateStatus($"Game started! Turn 1/{evt.TotalTurns}");
            
            if (EndTurnButton != null)
                EndTurnButton.interactable = true;
                
            if (StartGameButton != null)
                StartGameButton.interactable = false;
        }

        private void OnTurnStarted(TurnStartedEvent evt)
        {
            _currentTurn = evt.TurnNumber;
            _turnTimer = 30f;
            UpdateTurnIndicator(evt.TurnNumber, 6);
            UpdateStatus($"Your turn! Time: {Mathf.CeilToInt(_turnTimer)}s");
            
            if (EndTurnButton != null)
                EndTurnButton.interactable = true;
        }

        private void OnPlayerEndedTurn(PlayerEndedTurnEvent evt)
        {
            if (evt.PlayerId == (ulong)LocalPlayerId)
            {
                if (EndTurnButton != null)
                    EndTurnButton.interactable = false;
                UpdateStatus("Waiting for opponent...");
            }
        }

        private void OnCardPlayed(CardPlayedEvent evt)
        {
            UpdateStatus($"Card played by Player {evt.PlayerId}");
            AnimateCardToBoard(evt.PlayerId, evt.CardId);
        }

        private void OnScoreUpdated(ScoreUpdatedEvent evt)
        {
            if (evt.PlayerId == (ulong)LocalPlayerId)
            {
                _localScore = evt.NewScore;
            }
            else
            {
                _opponentScore = evt.NewScore;
            }
            UpdateScoreDisplay();
            UpdateStatus($"Scores updated: You {_localScore} - Opponent {_opponentScore}");
        }

        private void OnTurnEnded(TurnEndedEvent evt)
        {
            _turnTimer = 0f;
            UpdateStatus("Turn ended, calculating results...");
        }

        private void OnGameEnded(GameEndedEvent evt)
        {
            _isGameActive = false;
            _turnTimer = 0f;
            
            if (EndTurnButton != null)
                EndTurnButton.interactable = false;
                
            bool isWinner = evt.WinningPlayerId == (ulong)LocalPlayerId;
            UpdateStatus(isWinner ? "🎉 You Won! 🎉" : "😔 You Lost! 😔");
            ShowGameOverScreen(isWinner);
        }

        private void OnCommandRejected(CommandRejectedEvent evt)
        {
            UpdateStatus($"⚠️ {evt.Reason}");
        }

        // UI Interactions
        private void OnEndTurnClicked()
        {
            if (!_isGameActive) return;

            var command = new EndTurnCommand((ulong)LocalPlayerId);
            SendCommand(command);
            UpdateStatus("Ending turn...");
        }

        private void OnStartGameClicked()
        {
            var command = new StartMatchCommand((ulong)LocalPlayerId, 6);
            SendCommand(command);
            UpdateStatus("Starting game...");
        }

        private void SendCommand(ICommand command)
        {
            if (NetworkService.Instance != null)
            {
                NetworkService.Instance.SendCommandToServer(command);
            }
            else
            {
                // Fallback for local testing
                EventBus.Publish(new ClientCommandReceived(command));
            }
        }

        // UI Update Methods
        private void UpdateTurnIndicator(int turn, int maxTurns)
        {
            if (TurnIndicator != null)
            {
                TurnIndicator.text = $"🏏 Turn {turn}/{maxTurns}";
            }
        }

        private void UpdateScoreDisplay()
        {
            if (ScoreText != null)
            {
                ScoreText.text = $"📊 You: {_localScore}  |  Opponent: {_opponentScore}";
            }
        }

        private void UpdateStatus(string message)
        {
            if (StatusText != null)
            {
                StatusText.text = message;
            }
            Debug.Log($"[UI] {message}");
        }

        private void AnimateCardToBoard(ulong playerId, int cardId)
        {
            // In a real implementation, this would animate card movement
            Debug.Log($"Animating card {cardId} for player {playerId}");
        }

        private void ShowGameOverScreen(bool isWinner)
        {
            // Create game over popup
            var popup = new GameObject("GameOverPopup");
            var rect = popup.AddComponent<RectTransform>();
            var canvas = FindObjectOfType<Canvas>();
            rect.SetParent(canvas.transform, false);
            
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
            
            var image = popup.AddComponent<Image>();
            image.color = new Color(0, 0, 0, 0.8f);
            
            var textObj = new GameObject("ResultText");
            var textRect = textObj.AddComponent<RectTransform>();
            var tmpText = textObj.AddComponent<TextMeshProUGUI>();
            textRect.SetParent(rect, false);
            
            textRect.anchorMin = new Vector2(0.3f, 0.4f);
            textRect.anchorMax = new Vector2(0.7f, 0.6f);
            tmpText.text = isWinner ? "🎉 VICTORY! 🎉" : "😔 DEFEAT 😔";
            tmpText.fontSize = 48;
            tmpText.alignment = TextAlignmentOptions.Center;
            
            // Auto destroy after 3 seconds
            Destroy(popup, 3f);
        }

        // Demo/Test Methods
        private void SetupDemoHand()
        {
            // Create some demo cards for testing UI
            if (HandPanel != null && CardPrefab != null)
            {
                CreateDemoCard("Cover Drive", 2, 2, "Batsman", new List<string> { "Score", "Safe" }, "GainRuns", 2);
                CreateDemoCard("Yorker", 3, 3, "Bowler", new List<string> { "Wicket", "Control" }, "TakeWicket", 1);
                CreateDemoCard("Quick Single", 1, 1, "Batsman", new List<string> { "Tempo", "Utility" }, "ExtraAction", 1);
            }
        }

        private void CreateDemoCard(string name, int cost, int power, string role, List<string> tags, string abilityType, int abilityValue)
        {
            var cardObj = Instantiate(CardPrefab, HandPanel.transform);
            var cardDisplay = cardObj.GetComponent<CardDisplay>();
            
            if (cardDisplay != null)
            {
                cardDisplay.UpdateCardData(0, name, cost, power,role,tags, abilityType, abilityValue);
                _handCards.Add(cardDisplay);
            }
        }

        void Update()
        {
            // Update timer
            if (_isGameActive && _turnTimer > 0)
            {
                _turnTimer -= Time.deltaTime;
                if (TimerText != null)
                {
                    TimerText.text = Mathf.CeilToInt(_turnTimer).ToString();
                }
                
                // Flash warning when time is low
                if (_turnTimer <= 10 && TimerText != null)
                {
                    TimerText.color = Color.red;
                }
                else if (TimerText != null)
                {
                    TimerText.color = Color.white;
                }
            }
        }

        void OnDestroy()
        {
            // Clean up event subscriptions
            EventBus.Unsubscribe<GameStartedEvent>(OnGameStarted);
            EventBus.Unsubscribe<TurnStartedEvent>(OnTurnStarted);
            EventBus.Unsubscribe<PlayerEndedTurnEvent>(OnPlayerEndedTurn);
            EventBus.Unsubscribe<CardPlayedEvent>(OnCardPlayed);
            EventBus.Unsubscribe<ScoreUpdatedEvent>(OnScoreUpdated);
            EventBus.Unsubscribe<TurnEndedEvent>(OnTurnEnded);
            EventBus.Unsubscribe<GameEndedEvent>(OnGameEnded);
            EventBus.Unsubscribe<CommandRejectedEvent>(OnCommandRejected);
        }
    }
}