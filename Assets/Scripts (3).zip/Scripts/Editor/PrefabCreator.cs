#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using UnityEngine.UI;
using TMPro;

namespace CardDuel.EditorTools
{
    /// <summary>
    /// Editor tool to create game prefabs and setup scenes
    /// </summary>
    public class PrefabCreator : MonoBehaviour
    {
        [MenuItem("Card Duel/Create Game Prefabs")]
        public static void CreateGamePrefabs()
        {
            CreateCardPrefab();
            CreateUIManagerPrefab();
            CreateNetworkServicePrefab();
            Debug.Log("✅ Game prefabs created successfully!");
        }

        [MenuItem("Card Duel/Setup Main Scene")]
        public static void SetupMainScene()
        {
            CreateSceneStructure();
            Debug.Log("✅ Main scene structure created!");
        }

        private static void CreateCardPrefab()
        {
            // Create card prefab
            var cardObj = new GameObject("CardPrefab");
            
            // Add components
            var rectTransform = cardObj.AddComponent<RectTransform>();
            var image = cardObj.AddComponent<Image>();
            image.color = new Color(0.8f, 0.8f, 0.9f, 1f);
            
            // Setup rect transform
            rectTransform.sizeDelta = new Vector2(150, 200);
            
            // Create child elements
            CreateCardTextElement(cardObj, "CardName", "Card Name", new Vector2(0, 0.7f), new Vector2(1, 1));
            CreateCardTextElement(cardObj, "Cost", "2", new Vector2(0, 0.9f), new Vector2(0.3f, 1));
            CreateCardTextElement(cardObj, "Power", "3", new Vector2(0.7f, 0.9f), new Vector2(1, 1));
            CreateCardTextElement(cardObj, "Role", "BATSMAN", new Vector2(0, 0.8f), new Vector2(1, 0.9f));
            CreateCardTextElement(cardObj, "Tags", "Score, Safe", new Vector2(0, 0.6f), new Vector2(1, 0.7f));
            CreateCardTextElement(cardObj, "Ability", "Gain Runs: 2", new Vector2(0, 0), new Vector2(1, 0.6f));
            
            // Add button
            var button = cardObj.AddComponent<Button>();
            var buttonColors = button.colors;
            buttonColors.highlightedColor = new Color(0.9f, 0.9f, 1f);
            button.colors = buttonColors;
            
            // Save prefab
            SavePrefab(cardObj, "CardPrefab");
        }

        private static void CreateUIManagerPrefab()
        {
            var uiManagerObj = new GameObject("UIManager");
            uiManagerObj.AddComponent<Presentation.UI.UIManager>();
            
            SavePrefab(uiManagerObj, "UIManagerPrefab");
        }

        private static void CreateNetworkServicePrefab()
        {
            var networkObj = new GameObject("NetworkService");
            networkObj.AddComponent<Infrastructure.Networking.NetworkService>();
            
            SavePrefab(networkObj, "NetworkServicePrefab");
        }

        private static void CreateSceneStructure()
        {
            // Create main camera if needed
            if (Camera.main == null)
            {
                var cameraObj = new GameObject("Main Camera");
                var camera = cameraObj.AddComponent<Camera>();
                cameraObj.tag = "MainCamera";
            }

            // Create scene roots
            CreateSceneRoot("GAME_ROOT");
            CreateSceneRoot("UI_ROOT");
            CreateSceneRoot("NETWORK_ROOT");
        }

        private static void CreateSceneRoot(string name)
        {
            if (GameObject.Find(name) == null)
            {
                var rootObj = new GameObject(name);
                rootObj.transform.position = Vector3.zero;
            }
        }

        private static void CreateCardTextElement(GameObject parent, string name, string text, Vector2 anchorMin, Vector2 anchorMax)
        {
            var textObj = new GameObject(name);
            var rect = textObj.AddComponent<RectTransform>();
            var tmpText = textObj.AddComponent<TextMeshProUGUI>();
            
            rect.SetParent(parent.transform, false);
            rect.anchorMin = anchorMin;
            rect.anchorMax = anchorMax;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
            
            tmpText.text = text;
            tmpText.fontSize = 18;
            tmpText.alignment = TextAlignmentOptions.Center;
        }

        private static void SavePrefab(GameObject obj, string prefabName)
        {
            #if UNITY_EDITOR
            string path = $"Assets/Prefabs/{prefabName}.prefab";
            
            // Create directory if it doesn't exist
            string directory = System.IO.Path.GetDirectoryName(path);
            if (!System.IO.Directory.Exists(directory))
            {
                System.IO.Directory.CreateDirectory(directory);
            }
            
            // Create prefab
            PrefabUtility.SaveAsPrefabAsset(obj, path);
            DestroyImmediate(obj);
            #endif
        }
    }
}
#endif