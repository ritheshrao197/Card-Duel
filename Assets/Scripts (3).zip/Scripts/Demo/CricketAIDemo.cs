using UnityEngine;
using System.Collections.Generic;
using CardDuel.Domain.Data;
using CardDuel.Domain.Models.Cricket;
using CardDuel.Domain.Players;
using CardDuel.Domain.AI;

namespace CardDuel.Demo
{
    /// <summary>
    /// Demo script showing the cricket AI evaluation system in action
    /// </summary>
    public class CricketAIDemo : MonoBehaviour
    {
        [Header("Demo Settings")]
        public int HandSize = 5;
        public bool ShowDetailedEvaluation = true;

        private CricketCardDatabase _cardDatabase;
        private CricketAIPlayer _aiPlayer;
        private GameContext _demoContext;

        void Start()
        {
            InitializeDemo();
            RunDemo();
        }

        private void InitializeDemo()
        {
            // Load the cricket cards
            _cardDatabase = new CricketCardDatabase();
            _cardDatabase.LoadFromResources("Cards/CricketCards");
            
            Debug.Log($"Loaded {_cardDatabase.CardCount} cricket cards");

            // Create AI player
            _aiPlayer = new CricketAIPlayer(1);

            // Set up demo game context
            _demoContext = new GameContext
            {
                CurrentTurn = 3,
                MaxTurns = 6,
                PlayerScore = 15,
                OpponentScore = 18,
                PlayerHandSize = HandSize,
                OpponentHandSize = 4,
                EarlyGameFactor = 0.2f // Mid-game
            };
        }

        private void RunDemo()
        {
            // Get random hand for AI
            var aiHand = _cardDatabase.GetRandomCards(HandSize);
            
            // Initialize AI with hand to determine play style
            _aiPlayer.InitializeWithHand(aiHand);
            
            Debug.Log($"=== CRICKET AI DEMO ===");
            Debug.Log($"AI Deck Style: {_aiPlayer.DeckStyle}");
            Debug.Log($"Player Score: {_demoContext.PlayerScore}, Opponent Score: {_demoContext.OpponentScore}");
            Debug.Log($"Turn {_demoContext.CurrentTurn}/{_demoContext.MaxTurns}");
            Debug.Log("");

            // Show all cards in hand with evaluations
            Debug.Log("CARDS IN HAND:");
            foreach (var card in aiHand)
            {
                var evaluation = _aiPlayer.GetEvaluationDetails(card, _demoContext);
                Debug.Log($"{card.Name} (Role: {card.Role}, Cost: {card.Cost}, Power: {card.Power})");
                Debug.Log($"  Tags: [{string.Join(", ", card.Tags)}]");
                Debug.Log($"  Ability: {card.Ability?.Type} ({card.Ability?.Value})");
                
                if (ShowDetailedEvaluation)
                {
                    Debug.Log($"  Evaluation: {evaluation.FinalScore:F2}");
                    Debug.Log($"    Base: {evaluation.BaseValue:F2}, Ability: {evaluation.AbilityValue:F2}");
                    Debug.Log($"    Synergy: {evaluation.SynergyBonus:F2}, Context: {evaluation.ContextModifier:F2}");
                    Debug.Log($"    Cost Penalty: {evaluation.CostPenalty:F2}, Risk: {evaluation.RiskPenalty:F2}");
                }
                Debug.Log("");
            }

            // Show AI's choice
            var chosenCommand = _aiPlayer.MakePlayDecision(aiHand, _demoContext);
            if (chosenCommand is Domain.Commands.PlayCardCommand playCommand)
            {
                var chosenCard = _cardDatabase.GetCardById(playCommand.CardId);
                Debug.Log($"🤖 AI CHOOSES: {chosenCard.Name}");
                Debug.Log($"   Reasoning: High synergy with current game state");
            }
            else
            {
                Debug.Log("🤖 AI CHOOSES: End Turn");
                Debug.Log($"   Reasoning: No advantageous plays available");
            }

            // Show different scenarios
            Debug.Log("");
            Debug.Log("=== SCENARIO TESTING ===");
            
            TestScenario("Early Game Aggressive", new GameContext
            {
                CurrentTurn = 1,
                MaxTurns = 6,
                PlayerScore = 5,
                OpponentScore = 8,
                EarlyGameFactor = 0.5f
            });

            TestScenario("Late Game Defensive", new GameContext
            {
                CurrentTurn = 5,
                MaxTurns = 6,
                PlayerScore = 25,
                OpponentScore = 20,
                EarlyGameFactor = 0.0f
            });

            TestScenario("Behind Big Deficit", new GameContext
            {
                CurrentTurn = 4,
                MaxTurns = 6,
                PlayerScore = 10,
                OpponentScore = 25,
                EarlyGameFactor = 0.2f
            });
        }

        private void TestScenario(string scenarioName, GameContext context)
        {
            Debug.Log($"--- {scenarioName} ---");
            
            var testHand = _cardDatabase.GetRandomCards(5);
            var bestCard = new CricketAIEvaluator().ChooseBestCard(testHand, context);
            
            if (bestCard != null)
            {
                var evaluation = new CricketAIEvaluator().GetEvaluationBreakdown(bestCard, context);
                Debug.Log($"Best choice: {bestCard.Name} (Score: {evaluation.FinalScore:F2})");
                Debug.Log($"Role: {bestCard.Role}, Tags: [{string.Join(", ", bestCard.Tags)}]");
            }
            Debug.Log("");
        }

        [ContextMenu("Run Demo Again")]
        public void RunDemoAgain()
        {
            RunDemo();
        }

        void OnGUI()
        {
            if (GUI.Button(new Rect(10, 10, 150, 30), "Run AI Demo"))
            {
                RunDemo();
            }
        }
    }
}