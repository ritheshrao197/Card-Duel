using CardDuel.Domain;
using CardDuel.Domain.Commands;
using CardDuel.Domain.GameState;
using CardDuel.Networking;
using Unity.Netcode;

namespace CardDuel.Server
{
    public class MatchService
    {
        private readonly GameState _gameState = new();
        private readonly NetworkEventRelay _relay;

        public MatchService(NetworkEventRelay relay)
        {
            _relay = relay;
        }

        public void Handle(ICommand command)
        {
            var events = _gameState.Apply(command);
            foreach (var evt in events)
                _relay.Broadcast(evt);
        }
    }
}
