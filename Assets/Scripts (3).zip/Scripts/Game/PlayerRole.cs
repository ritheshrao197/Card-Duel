namespace CardDuel.Domain.GameState
{
    public enum PlayerRole
{
    Player1,
    Player2
}
}