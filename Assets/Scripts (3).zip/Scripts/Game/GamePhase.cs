namespace CardDuel.Domain.GameState
{
    public enum GamePhase
{
    WaitingForPlayers,
    TurnInProgress,
    RevealingCards,
    TurnComplete,
    GameOver
}
}