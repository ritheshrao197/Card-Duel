using UnityEngine;
using UnityEngine.UI;
using TMPro;
using CardDuel.Bootstrap;
using CardDuel.Infrastructure.Networking;
using CardDuel.Presentation.UI;

namespace CardDuel.SceneSetup
{
    /// <summary>
    /// Main scene setup manager - creates and configures all game objects
    /// </summary>
    public class GameSceneSetup : MonoBehaviour
    {
        [Header("Scene References")]
        public Transform UIRoot;
        public Transform GameRoot;
        public Transform NetworkRoot;

        [Header("Prefab References")]
        public GameObject UIManagerPrefab;
        public GameObject NetworkServicePrefab;
        public GameObject GameInstallerPrefab;
        public GameObject CardPrefab;

        [Header("UI Canvas Setup")]
        public Canvas MainCanvas;
        public Camera UICamera;

        void Start()
        {
            SetupScene();
        }

        private void SetupScene()
        {
            // Ensure we have the basic scene structure
            EnsureSceneStructure();
            
            // Create core game systems
            CreateGameSystems();
            
            // Setup UI
            SetupUI();
            
            // Setup networking
            SetupNetworking();
            
            Debug.Log("🎮 Game scene setup complete!");
        }

        private void EnsureSceneStructure()
        {
            // Create root objects if they don't exist
            if (UIRoot == null)
            {
                var uiRootObj = new GameObject("UI_ROOT");
                UIRoot = uiRootObj.transform;
            }

            if (GameRoot == null)
            {
                var gameRootObj = new GameObject("GAME_ROOT");
                GameRoot = gameRootObj.transform;
            }

            if (NetworkRoot == null)
            {
                var networkRootObj = new GameObject("NETWORK_ROOT");
                NetworkRoot = networkRootObj.transform;
            }

            // Setup canvas if needed
            if (MainCanvas == null)
            {
                var canvasObj = new GameObject("MainCanvas");
                MainCanvas = canvasObj.AddComponent<Canvas>();
                MainCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
                
                var canvasScaler = canvasObj.AddComponent<CanvasScaler>();
                canvasScaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
                canvasScaler.referenceResolution = new Vector2(1920, 1080);
                
                canvasObj.AddComponent<GraphicRaycaster>();
                
                canvasObj.transform.SetParent(UIRoot, false);
            }

            // Setup UI camera if needed
            if (UICamera == null)
            {
                var cameraObj = new GameObject("UICamera");
                UICamera = cameraObj.AddComponent<Camera>();
                UICamera.cullingMask = 1 << 5; // UI layer
                UICamera.clearFlags = CameraClearFlags.Depth;
                UICamera.depth = 100;
                cameraObj.transform.SetParent(UIRoot, false);
            }
        }

        private void CreateGameSystems()
        {
            // Create Game Installer (core game logic)
            if (GameInstallerPrefab != null)
            {
                var installerObj = Instantiate(GameInstallerPrefab, GameRoot);
                installerObj.name = "GameInstaller";
            }
            else
            {
                // Fallback: create directly
                var installerObj = new GameObject("GameInstaller");
                installerObj.AddComponent<GameInstaller>();
                installerObj.transform.SetParent(GameRoot, false);
            }

            Debug.Log("📦 Game systems created");
        }

        private void SetupUI()
        {
            // Create UI Manager
            GameObject uiManagerObj;
            if (UIManagerPrefab != null)
            {
                uiManagerObj = Instantiate(UIManagerPrefab, MainCanvas.transform);
            }
            else
            {
                uiManagerObj = new GameObject("UIManager");
                var uiManager = uiManagerObj.AddComponent<UIManager>();
                SetupDefaultUI(uiManager);
            }
            
            uiManagerObj.name = "UIManager";
            uiManagerObj.transform.SetParent(MainCanvas.transform, false);

            Debug.Log("🎨 UI system setup complete");
        }

        private void SetupNetworking()
        {
            // Create Network Service
            GameObject networkObj;
            if (NetworkServicePrefab != null)
            {
                networkObj = Instantiate(NetworkServicePrefab, NetworkRoot);
            }
            else
            {
                networkObj = new GameObject("NetworkService");
                networkObj.AddComponent<NetworkService>();
            }
            
            networkObj.name = "NetworkService";
            networkObj.transform.SetParent(NetworkRoot, false);

            Debug.Log("🌐 Networking system setup complete");
        }

        private void SetupDefaultUI(UIManager uiManager)
        {
            // Create main UI panels
            var mainPanel = CreateUIPanel("MainPanel", MainCanvas.transform);
            mainPanel.anchorMin = Vector2.zero;
            mainPanel.anchorMax = Vector2.one;
            mainPanel.offsetMin = Vector2.zero;
            mainPanel.offsetMax = Vector2.zero;

            // Create hand area
            var handPanel = CreateUIPanel("HandPanel", mainPanel.transform);
            handPanel.anchorMin = new Vector2(0, 0);
            handPanel.anchorMax = new Vector2(1, 0.3f);
            handPanel.offsetMin = new Vector2(50, 50);
            handPanel.offsetMax = new Vector2(-50, -50);

            // Create board area
            var boardPanel = CreateUIPanel("BoardPanel", mainPanel.transform);
            boardPanel.anchorMin = new Vector2(0, 0.3f);
            boardPanel.anchorMax = new Vector2(1, 0.7f);
            boardPanel.offsetMin = new Vector2(100, 20);
            boardPanel.offsetMax = new Vector2(-100, -20);

            // Create info panel
            var infoPanel = CreateUIPanel("InfoPanel", mainPanel.transform);
            infoPanel.anchorMin = new Vector2(0, 0.7f);
            infoPanel.anchorMax = new Vector2(1, 1);
            infoPanel.offsetMin = new Vector2(50, 20);
            infoPanel.offsetMax = new Vector2(-50, -50);

            // Assign to UI manager
            uiManager.HandPanel = handPanel.gameObject;
            uiManager.BoardPanel = boardPanel.gameObject;

            // Create UI elements
            CreateInfoElements(infoPanel.transform, uiManager);
            CreateControlButtons(mainPanel.transform, uiManager);
        }

        private RectTransform CreateUIPanel(string name, Transform parent)
        {
            var panelObj = new GameObject(name);
            var panel = panelObj.AddComponent<RectTransform>();
            var image = panelObj.AddComponent<Image>();
            image.color = new Color(0.1f, 0.1f, 0.1f, 0.7f);
            
            panel.SetParent(parent, false);
            return panel;
        }

        private void CreateInfoElements(Transform parent, UIManager uiManager)
        {
            // Turn indicator
            var turnObj = CreateTextElement("TurnIndicator", parent, "Turn 1/6");
            turnObj.anchorMin = new Vector2(0, 0.7f);
            turnObj.anchorMax = new Vector2(0.5f, 1);
            uiManager.TurnIndicator = turnObj.GetComponent<TextMeshProUGUI>();

            // Score display
            var scoreObj = CreateTextElement("ScoreText", parent, "Score: 0 - 0");
            scoreObj.anchorMin = new Vector2(0.5f, 0.7f);
            scoreObj.anchorMax = new Vector2(1, 1);
            uiManager.ScoreText = scoreObj.GetComponent<TextMeshProUGUI>();

            // Timer display
            var timerObj = CreateTextElement("TimerText", parent, "30");
            timerObj.anchorMin = new Vector2(0, 0);
            timerObj.anchorMax = new Vector2(0.3f, 0.7f);
            timerObj.GetComponent<TextMeshProUGUI>().fontSize = 48;
            uiManager.TimerText = timerObj.GetComponent<TextMeshProUGUI>();
        }

        private void CreateControlButtons(Transform parent, UIManager uiManager)
        {
            // End Turn button
            var buttonObj = new GameObject("EndTurnButton");
            var buttonRect = buttonObj.AddComponent<RectTransform>();
            var button = buttonObj.AddComponent<Button>();
            var buttonImage = buttonObj.AddComponent<Image>();
            buttonImage.color = Color.red;
            
            buttonRect.SetParent(parent, false);
            buttonRect.anchorMin = new Vector2(0.7f, 0);
            buttonRect.anchorMax = new Vector2(1, 0.3f);
            buttonRect.offsetMin = Vector2.zero;
            buttonRect.offsetMax = Vector2.zero;

            // Button text
            var textObj = CreateTextElement("ButtonText", buttonRect, "END TURN");
            textObj.GetComponent<TextMeshProUGUI>().fontSize = 24;
            
            uiManager.EndTurnButton = button;
        }

        private RectTransform CreateTextElement(string name, Transform parent, string text)
        {
            var textObj = new GameObject(name);
            var rectTransform = textObj.AddComponent<RectTransform>();
            var tmpText = textObj.AddComponent<TextMeshProUGUI>();
            
            tmpText.text = text;
            tmpText.fontSize = 36;
            tmpText.color = Color.white;
            tmpText.alignment = TextAlignmentOptions.Center;
            
            rectTransform.SetParent(parent, false);
            rectTransform.anchorMin = Vector2.zero;
            rectTransform.anchorMax = Vector2.one;
            rectTransform.offsetMin = Vector2.zero;
            rectTransform.offsetMax = Vector2.zero;
            
            return rectTransform;
        }

        [ContextMenu("Setup Scene")]
        public void SetupSceneManually()
        {
            SetupScene();
        }
    }
}