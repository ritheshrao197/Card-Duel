using System.Collections.Generic;

namespace CardDuel.Domain.Models
{

    /// <summary>
    /// Represents a card that has been played/folded
    /// </summary>
    public class PlayedCard
    {
        public int CardId { get; }
        public int OrderIndex { get; }
        public bool IsRevealed { get; set; }

        public PlayedCard(int cardId, int orderIndex)
        {
            CardId = cardId;
            OrderIndex = orderIndex;
            IsRevealed = false;
        }
    }
}