using System;

namespace CardDuel.Domain.Models
{
    /// <summary>
    /// Card ability definition
    /// </summary>
    public class CardAbility
    {
        public string Type { get; } // "GainPoints", "StealPoints", "DoublePower", etc.
        public int Value { get; }

        public CardAbility(string type, int value)
        {
            Type = type ?? throw new ArgumentNullException(nameof(type));
            Value = value;
        }

        public CardAbility Clone()
        {
            return new CardAbility(Type, Value);
        }
    }
}