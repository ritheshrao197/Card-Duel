using System;
using System.Collections.Generic;

namespace CardDuel.Domain.Models.Cricket
{
    /// <summary>
    /// Enhanced cricket card model supporting the new JSON structure
    /// </summary>
    public class CricketCard
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Cost { get; set; }
        public int Power { get; set; }
        public string Role { get; set; } // Batsman, Bowler, Fielding, Support
        public List<string> Tags { get; set; } // Score, Risk, Defense, etc.
        public CricketCardAbility Ability { get; set; }

        public CricketCard()
        {
            Tags = new List<string>();
        }

        public CricketCard Clone()
        {
            return new CricketCard
            {
                Id = this.Id,
                Name = this.Name,
                Cost = this.Cost,
                Power = this.Power,
                Role = this.Role,
                Tags = new List<string>(this.Tags),
                Ability = this.Ability?.Clone()
            };
        }

        public bool HasTag(string tag)
        {
            return Tags.Contains(tag);
        }

        public bool IsBatsman() => Role == "Batsman";
        public bool IsBowler() => Role == "Bowler";
        public bool IsFielding() => Role == "Fielding";
        public bool IsSupport() => Role == "Support";
    }

    /// <summary>
    /// Cricket-specific card abilities
    /// </summary>
    public class CricketCardAbility
    {
        public string Type { get; set; } // GainRuns, TakeWicket, DrawExtraCard, etc.
        public int Value { get; set; }

        public CricketCardAbility Clone()
        {
            return new CricketCardAbility
            {
                Type = this.Type,
                Value = this.Value
            };
        }
    }

    /// <summary>
    /// Game context for AI evaluation
    /// </summary>
    public class GameContext
    {
        public int CurrentTurn { get; set; }
        public int MaxTurns { get; set; }
        public int PlayerScore { get; set; }
        public int OpponentScore { get; set; }
        public int PlayerHandSize { get; set; }
        public int OpponentHandSize { get; set; }
        public string LastPlayedCardRole { get; set; }
        public List<string> LastPlayedCardTags { get; set; }
        public float EarlyGameFactor { get; set; }
        public DeckStyle AiDeckStyle { get; set; }

        public GameContext()
        {
            LastPlayedCardTags = new List<string>();
        }

        public int ScoreDeficit => OpponentScore - PlayerScore;
        public int ScoreLead => PlayerScore - OpponentScore;
        public bool IsEarlyGame => CurrentTurn <= MaxTurns / 3;
        public bool IsMidGame => CurrentTurn > MaxTurns / 3 && CurrentTurn <= 2 * MaxTurns / 3;
        public bool IsLateGame => CurrentTurn > 2 * MaxTurns / 3;
    }

    /// <summary>
    /// AI deck playing styles
    /// </summary>
    public enum DeckStyle
    {
        Aggro,    // Focus on burst damage/scores
        Control,  // Focus on defense/stalling
        Tempo     // Focus on card efficiency/tempo
    }

    /// <summary>
    /// Synergy rule for tag combinations
    /// </summary>
    public class SynergyRule
    {
        public string TagA { get; set; }
        public string TagB { get; set; }
        public float BonusValue { get; set; }

        public SynergyRule(string tagA, string tagB, float bonusValue)
        {
            TagA = tagA;
            TagB = tagB;
            BonusValue = bonusValue;
        }
    }

    /// <summary>
    /// Ability weights for AI evaluation
    /// </summary>
    public static class AbilityWeights
    {
        private static readonly Dictionary<string, float> _weights = new Dictionary<string, float>
        {
            {"GainRuns", 1.0f},
            {"HighRiskRuns", 1.5f},
            {"TakeWicket", 3.0f},
            {"DrawExtraCard", 1.5f},
            {"CancelOpponentEffect", 2.0f},
            {"ReduceIncomingRuns", 1.8f},
            {"DoubleRunsThisTurn", 2.5f},
            {"ChainWicket", 3.5f},
            {"ForceDiscard", 1.2f},
            {"ReduceOpponentRuns", 1.8f},
            {"DelayedWicket", 2.0f},
            {"IgnoreDefense", 2.2f},
            {"CancelNextAction", 1.5f},
            {"BonusIfOpponentLow", 2.0f},
            {"NegateHighRunCard", 2.0f},
            {"ConditionalWicket", 2.5f},
            {"ReorderUpcomingCards", 1.5f},
            {"ReduceAllOpponentRuns", 2.0f},
            {"ResetTemporaryEffects", 1.0f},
            {"RecoverResources", 1.8f},
            {"CounterAttack", 2.0f},
            {"CopyLastCardReduced", 1.5f},
            {"ChanceToLoseWicket", -1.0f} // Negative weight for risky abilities
        };

        public static float GetWeight(string abilityType)
        {
            return _weights.TryGetValue(abilityType, out float weight) ? weight : 0f;
        }
    }
}