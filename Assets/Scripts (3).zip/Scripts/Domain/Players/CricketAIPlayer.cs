using System.Collections.Generic;
using CardDuel.Domain.Models.Cricket;
using CardDuel.Domain.AI;
using CardDuel.Domain.Commands;
using CardDuel.Core;
using CardDuel.Domain.Models;

namespace CardDuel.Domain.Players
{
    /// <summary>
    /// AI player that uses the cricket evaluation system
    /// Makes intelligent decisions based on the production-ready AI model
    /// </summary>
    public class CricketAIPlayer
    {
        private readonly CricketAIEvaluator _evaluator;
        private readonly ulong _playerId;
        private DeckStyle _deckStyle;
        private string _lastPlayedCardRole;
        private List<string> _lastPlayedCardTags;

        public ulong PlayerId => _playerId;
        public DeckStyle DeckStyle => _deckStyle;

        public CricketAIPlayer(ulong playerId)
        {
            _playerId = playerId;
            _evaluator = new CricketAIEvaluator();
            _lastPlayedCardTags = new List<string>();
        }

        /// <summary>
        /// Initialize AI with starting hand to determine play style
        /// </summary>
        public void InitializeWithHand(List<CricketCard> startingHand)
        {
            _deckStyle = _evaluator.DetermineDeckStyle(startingHand);
        }

        /// <summary>
        /// Make decision on which card to play
        /// </summary>
        public ICommand MakePlayDecision(List<CricketCard> hand, GameContext context)
        {
            // Update context with AI's last played card info
            context.LastPlayedCardRole = _lastPlayedCardRole;
            context.LastPlayedCardTags = new List<string>(_lastPlayedCardTags);
            context.AiDeckStyle = _deckStyle;

            // Let AI choose the best card
            var bestCard = _evaluator.ChooseBestCard(hand, context);
            
            if (bestCard != null)
            {
                // Remember this card for synergy calculations next turn
                _lastPlayedCardRole = bestCard.Role;
                _lastPlayedCardTags = new List<string>(bestCard.Tags);
                
                return new PlayCardCommand(_playerId, bestCard.Id);
            }

            // If no good card to play, end turn
            return new EndTurnCommand(_playerId);
        }

        /// <summary>
        /// Get detailed evaluation for debugging/tuning
        /// </summary>
        public EvaluationBreakdown GetEvaluationDetails(CricketCard card, GameContext context)
        {
            context.LastPlayedCardRole = _lastPlayedCardRole;
            context.LastPlayedCardTags = new List<string>(_lastPlayedCardTags);
            context.AiDeckStyle = _deckStyle;
            
            return _evaluator.GetEvaluationBreakdown(card, context);
        }

        /// <summary>
        /// Reset AI state for new game
        /// </summary>
        public void Reset()
        {
            _lastPlayedCardRole = null;
            _lastPlayedCardTags.Clear();
        }
    }

    /// <summary>
    /// Extension methods for converting between domain models and game context
    /// </summary>
    public static class CricketAIExtensions
    {
        /// <summary>
        /// Convert match state to AI game context
        /// </summary>
        public static GameContext ToGameContext(this Domain.State.GameState gameState, ulong aiPlayerId)
        {
            var context = new GameContext
            {
                CurrentTurn = GameState.CurrentTurn,
                MaxTurns = GameState.MaxTurns,
                PlayerHandSize = GameState.PlayerStates.ContainsKey(aiPlayerId) ? 
                    GameState.PlayerStates[aiPlayerId].Hand.Count : 0,
                EarlyGameFactor = GameState.CurrentTurn <= GameState.MaxTurns / 3 ? 0.5f : 
                                GameState.CurrentTurn <= 2 * GameState.MaxTurns / 3 ? 0.2f : 0.0f
            };

            // Find opponent ID and set scores
            foreach (var kvp in GameState.PlayerStates)
            {
                if (kvp.Key == aiPlayerId)
                {
                    context.PlayerScore = kvp.Value.Score;
                }
                else
                {
                    context.OpponentScore = kvp.Value.Score;
                    context.OpponentHandSize = kvp.Value.Hand.Count;
                }
            }

            return context;
        }

        /// <summary>
        /// Convert cricket cards to regular cards for compatibility
        /// </summary>
        public static List<Card> ToRegularCards(this List<CricketCard> cricketCards)
        {
            var regularCards = new List<Card>();
            foreach (var cricketCard in cricketCards)
            {
                regularCards.Add(new Card(
                    cricketCard.Id,
                    cricketCard.Name,
                    cricketCard.Cost,
                    cricketCard.Power,
                    cricketCard.Ability != null ? 
                        new CardAbility(cricketCard.Ability.Type, cricketCard.Ability.Value) : null
                ));
            }
            return regularCards;
        }
    }
}