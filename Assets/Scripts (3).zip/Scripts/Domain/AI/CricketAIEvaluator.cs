using System.Collections.Generic;
using System.Linq;
using CardDuel.Domain.Models.Cricket;

namespace CardDuel.Domain.AI
{
    /// <summary>
    /// Production-ready AI evaluation system for cricket card game
    /// Data-driven, no hardcoding, fully expandable
    /// </summary>
    public class CricketAIEvaluator
    {
        private readonly List<SynergyRule> _synergyRules;
        private readonly Dictionary<DeckStyle, List<string>> _deckStylePreferences;

        public CricketAIEvaluator()
        {
            // Initialize synergy rules (same as specified in the design)
            _synergyRules = new List<SynergyRule>
            {
                new SynergyRule("Tempo", "Combo", 1.5f),
                new SynergyRule("Control", "Delayed", 1.2f),
                new SynergyRule("Burst", "Finisher", 2.0f),
                new SynergyRule("Disrupt", "Punish", 1.5f),
                new SynergyRule("Defense", "Stall", 1.3f)
            };

            // Initialize deck style preferences
            _deckStylePreferences = new Dictionary<DeckStyle, List<string>>
            {
                { DeckStyle.Aggro, new List<string> { "Burst", "Finisher", "HighRisk" } },
                { DeckStyle.Control, new List<string> { "Defense", "Stall", "Control" } },
                { DeckStyle.Tempo, new List<string> { "Tempo", "Utility", "Efficiency" } }
            };
        }

        /// <summary>
        /// Main AI evaluation function - chooses the best card to play
        /// </summary>
        public CricketCard ChooseBestCard(List<CricketCard> hand, GameContext context)
        {
            if (hand == null || hand.Count == 0)
                return null;

            var scoredCards = hand.Select(card => new
            {
                Card = card,
                Score = EvaluateCard(card, context)
            }).ToList();

            // Return the card with highest score
            return scoredCards.OrderByDescending(x => x.Score).First().Card;
        }

        /// <summary>
        /// Core AI evaluation formula
        /// FinalScore = BaseValue + AbilityValue + SynergyBonus + ContextModifier - RiskPenalty - CostPenalty
        /// </summary>
        public float EvaluateCard(CricketCard card, GameContext context)
        {
            float score = 0f;

            // 1. BaseValue (Power efficiency)
            score += card.Power * 1.0f;

            // 2. AbilityValue (what the card does)
            if (card.Ability != null)
            {
                score += AbilityWeights.GetWeight(card.Ability.Type) * card.Ability.Value;
            }

            // 3. SynergyBonus (card combinations)
            score += CalculateSynergyBonus(card, context);

            // 4. ContextModifier (game state awareness)
            score += CalculateContextModifier(card, context);

            // 5. CostPenalty (tempo awareness)
            score -= card.Cost * context.EarlyGameFactor;

            // 6. RiskPenalty (risk management)
            if (card.HasTag("Risk") || card.HasTag("HighRisk"))
            {
                score -= 1.5f;
            }

            return score;
        }

        /// <summary>
        /// Calculate synergy bonuses based on tags and role combinations
        /// </summary>
        private float CalculateSynergyBonus(CricketCard card, GameContext context)
        {
            float bonus = 0f;

            // Same-role synergy
            if (!string.IsNullOrEmpty(context.LastPlayedCardRole) && 
                card.Role == context.LastPlayedCardRole)
            {
                bonus += 1.0f;
            }

            // Tag pair synergies
            foreach (var rule in _synergyRules)
            {
                if (context.LastPlayedCardTags.Contains(rule.TagA) && card.HasTag(rule.TagB))
                {
                    bonus += rule.BonusValue;
                }
            }

            // Sequence synergy (last card tags influencing current card)
            if (context.LastPlayedCardTags.Contains("Control") && card.HasTag("Finisher"))
            {
                bonus += 1.5f;
            }

            if (context.LastPlayedCardTags.Contains("Tempo") && card.HasTag("Burst"))
            {
                bonus += 1.5f;
            }

            if (context.LastPlayedCardTags.Contains("Defense") && card.HasTag("Reset"))
            {
                bonus += 1.5f;
            }

            // Deck archetype bias
            if (_deckStylePreferences.ContainsKey(context.AiDeckStyle))
            {
                var preferredTags = _deckStylePreferences[context.AiDeckStyle];
                foreach (var tag in card.Tags)
                {
                    if (preferredTags.Contains(tag))
                    {
                        bonus += 1.5f;
                    }
                }
            }

            // Anti-synergy (prevent wasteful plays)
            if (card.HasTag("Reset") && NoActiveEffects(context))
            {
                bonus -= 2.0f;
            }

            return bonus;
        }

        /// <summary>
        /// Calculate context modifiers based on game state
        /// </summary>
        private float CalculateContextModifier(CricketCard card, GameContext context)
        {
            float modifier = 0f;

            // Behind in score - aggressive plays
            if (context.ScoreDeficit > 5 && card.HasTag("Burst"))
            {
                modifier += 2.0f;
            }

            if (context.ScoreDeficit > 3 && card.HasTag("HighRisk"))
            {
                modifier += 1.5f;
            }

            // Ahead in score - defensive plays
            if (context.ScoreLead > 5 && card.HasTag("Defense"))
            {
                modifier += 1.5f;
            }

            if (context.ScoreLead > 3 && card.HasTag("Stall"))
            {
                modifier += 1.0f;
            }

            // Opponent hand size advantages
            if (context.OpponentHandSize <= 2 && card.HasTag("Disrupt"))
            {
                modifier += 2.0f;
            }

            if (context.OpponentHandSize <= 1 && card.HasTag("Punish"))
            {
                modifier += 2.5f;
            }

            // Late game finishers
            if (context.IsLateGame && card.HasTag("Finisher"))
            {
                modifier += 2.0f;
            }

            // Early game efficiency
            if (context.IsEarlyGame && card.HasTag("Utility"))
            {
                modifier += 1.5f;
            }

            return modifier;
        }

        /// <summary>
        /// Check if there are no active effects to reset
        /// </summary>
        private bool NoActiveEffects(GameContext context)
        {
            // In a real implementation, this would check actual game state
            // For now, we'll use a simple heuristic
            return context.CurrentTurn <= 2; // Assume no effects early in game
        }

        /// <summary>
        /// Determine AI deck style based on initial hand analysis
        /// </summary>
        public DeckStyle DetermineDeckStyle(List<CricketCard> initialHand)
        {
            var tagCounts = new Dictionary<string, int>();
            
            // Count tags in initial hand
            foreach (var card in initialHand)
            {
                foreach (var tag in card.Tags)
                {
                    if (!tagCounts.ContainsKey(tag))
                        tagCounts[tag] = 0;
                    tagCounts[tag]++;
                }
            }

            // Determine style based on dominant tags
            if (tagCounts.GetValueOrDefault("Burst", 0) + tagCounts.GetValueOrDefault("HighRisk", 0) >= 3)
                return DeckStyle.Aggro;
            
            if (tagCounts.GetValueOrDefault("Defense", 0) + tagCounts.GetValueOrDefault("Stall", 0) >= 3)
                return DeckStyle.Control;
            
            if (tagCounts.GetValueOrDefault("Tempo", 0) + tagCounts.GetValueOrDefault("Utility", 0) >= 3)
                return DeckStyle.Tempo;

            // Default to balanced approach
            return DeckStyle.Tempo;
        }

        /// <summary>
        /// Get evaluation breakdown for debugging/tuning
        /// </summary>
        public EvaluationBreakdown GetEvaluationBreakdown(CricketCard card, GameContext context)
        {
            var breakdown = new EvaluationBreakdown
            {
                BaseValue = card.Power * 1.0f,
                AbilityValue = card.Ability != null ? AbilityWeights.GetWeight(card.Ability.Type) * card.Ability.Value : 0f,
                SynergyBonus = CalculateSynergyBonus(card, context),
                ContextModifier = CalculateContextModifier(card, context),
                CostPenalty = -(card.Cost * context.EarlyGameFactor),
                RiskPenalty = (card.HasTag("Risk") || card.HasTag("HighRisk")) ? -1.5f : 0f
            };

            breakdown.FinalScore = breakdown.BaseValue + breakdown.AbilityValue + 
                                 breakdown.SynergyBonus + breakdown.ContextModifier + 
                                 breakdown.CostPenalty + breakdown.RiskPenalty;

            return breakdown;
        }
    }

    /// <summary>
    /// Detailed breakdown of AI evaluation for debugging
    /// </summary>
    public class EvaluationBreakdown
    {
        public float BaseValue { get; set; }
        public float AbilityValue { get; set; }
        public float SynergyBonus { get; set; }
        public float ContextModifier { get; set; }
        public float CostPenalty { get; set; }
        public float RiskPenalty { get; set; }
        public float FinalScore { get; set; }
    }
}