using System.Collections.Generic;
using UnityEngine;
using System.IO;
using CardDuel.Domain.Models.Cricket;

namespace CardDuel.Domain.Data
{
    /// <summary>
    /// Loads cricket cards from JSON data
    /// Fully data-driven, supports the specified JSON structure
    /// </summary>
    public class CricketCardDatabase
    {
        private List<CricketCard> _cards;
        private Dictionary<int, CricketCard> _cardLookup;

        public IReadOnlyList<CricketCard> Cards => _cards.AsReadOnly();
        public int CardCount => _cards.Count;

        public CricketCardDatabase()
        {
            _cards = new List<CricketCard>();
            _cardLookup = new Dictionary<int, CricketCard>();
        }

        /// <summary>
        /// Load cards from JSON string (as provided in the specification)
        /// </summary>
        public void LoadFromJson(string jsonString)
        {
            try
            {
                var wrapper = JsonUtility.FromJson<CardDataWrapper>(jsonString);
                if (wrapper?.cards != null)
                {
                    _cards.Clear();
                    _cardLookup.Clear();

                    foreach (var cardData in wrapper.cards)
                    {
                        var card = ConvertToCricketCard(cardData);
                        _cards.Add(card);
                        _cardLookup[card.Id] = card;
                    }

                    Debug.Log($"Loaded {_cards.Count} cricket cards from JSON");
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"Failed to load cricket cards from JSON: {ex.Message}");
            }
        }

        /// <summary>
        /// Load cards from Resources folder
        /// </summary>
        public void LoadFromResources(string resourceName)
        {
            TextAsset textAsset = Resources.Load<TextAsset>(resourceName);
            if (textAsset != null)
            {
                LoadFromJson(textAsset.text);
            }
            else
            {
                Debug.LogError($"Could not find resource: {resourceName}");
            }
        }

        /// <summary>
        /// Get card by ID
        /// </summary>
        public CricketCard GetCardById(int id)
        {
            return _cardLookup.TryGetValue(id, out CricketCard card) ? card : null;
        }

        /// <summary>
        /// Get cards by role
        /// </summary>
        public List<CricketCard> GetCardsByRole(string role)
        {
            return _cards.FindAll(card => card.Role == role);
        }

        /// <summary>
        /// Get cards by tag
        /// </summary>
        public List<CricketCard> GetCardsByTag(string tag)
        {
            return _cards.FindAll(card => card.HasTag(tag));
        }

        /// <summary>
        /// Get random cards for starting hand
        /// </summary>
        public List<CricketCard> GetRandomCards(int count)
        {
            var result = new List<CricketCard>();
            var availableCards = new List<CricketCard>(_cards);
            
            for (int i = 0; i < count && availableCards.Count > 0; i++)
            {
                int randomIndex = Random.Range(0, availableCards.Count);
                result.Add(availableCards[randomIndex].Clone());
                availableCards.RemoveAt(randomIndex);
            }
            
            return result;
        }

        /// <summary>
        /// Convert JSON data structure to domain model
        /// </summary>
        private CricketCard ConvertToCricketCard(CardData cardData)
        {
            return new CricketCard
            {
                Id = cardData.Id,
                Name = cardData.Name,
                Cost = cardData.Cost,
                Power = cardData.Power,
                Role = cardData.Role,
                Tags = cardData.Tags ?? new List<string>(),
                Ability = cardData.Ability != null ? new CricketCardAbility
                {
                    Type = cardData.Ability.Type,
                    Value = cardData.Ability.Value
                } : null
            };
        }

        /// <summary>
        /// JSON wrapper classes for deserialization
        /// </summary>
        [System.Serializable]
        private class CardDataWrapper
        {
            public List<CardData> cards;
        }

        [System.Serializable]
        private class CardData
        {
            public int Id;
            public string Name;
            public int Cost;
            public int Power;
            public string Role;
            public List<string> Tags;
            public AbilityData Ability;
        }

        [System.Serializable]
        private class AbilityData
        {
            public string Type;
            public int Value;
        }
    }
}