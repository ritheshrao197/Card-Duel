using CardDuel.UI.Core;
using CardDuel.UI.Events;
using CardDuel.Core;

public class MainMenuPanel : UIPanel
{
    public override UIState State => UIState.MainMenu;

    public void OnHostClicked()
    {
        UIGameEventBus.Publish(new NetworkUIIntent.HostRequested());
    }

    public void OnJoinClicked()
    {
        UIGameEventBus.Publish(new NetworkUIIntent.ClientRequested());
    }
}
