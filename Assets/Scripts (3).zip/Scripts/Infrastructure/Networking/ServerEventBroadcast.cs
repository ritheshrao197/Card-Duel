using CardDuel.Domain.Events;

namespace CardDuel.Infrastructure.Networking
{
    /// <summary>
    /// Event for server broadcasting to clients
    /// </summary>
    public class ServerEventBroadcast : IGameEvent
    {
        public IGameEvent Event { get; }

        public ServerEventBroadcast(IGameEvent evt)
        {
            Event = evt;
        }
    }
}